export interface Category {
    status: boolean;
    result: Category[];
}


export interface Category {
    cid:  number;
    name: string;
}
