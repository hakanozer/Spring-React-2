export interface User {
    name:    string;
    uid:     string;
    surname: string;
    email:   string;
    password:string;
    role:    string;
}