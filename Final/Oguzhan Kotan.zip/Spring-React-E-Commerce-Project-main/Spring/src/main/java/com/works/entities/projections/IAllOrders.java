package com.works.entities.projections;

public interface IAllOrders {
    String getEmail();
    String getBrand();
    String getTitle();
    String getPrice();
    String getStock();
    String getQuantity();
}
