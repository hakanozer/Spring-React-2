package com.works.entities.projections;

public interface IOrder {
    String getOid();
    String getBrand();
    String getTitle();
    String getPrice();
    String getStock();
    String getQuantity();
}
