package com.works.entities.projections;

public interface IProductCategory {
    String getPid();
    String getBrand();
    String getPrice();
    String getStock();
    String getTitle();
}
