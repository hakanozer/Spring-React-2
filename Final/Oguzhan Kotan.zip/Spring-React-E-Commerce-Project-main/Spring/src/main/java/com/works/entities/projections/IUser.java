package com.works.entities.projections;

public interface IUser {
    String getUid();
    String getName();
    String getSurname();
    String getEmail();
    String getPassword();
    String getRole();
}
