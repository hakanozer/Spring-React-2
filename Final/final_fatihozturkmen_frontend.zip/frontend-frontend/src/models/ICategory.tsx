export interface ICategory {
    cid:  number;
    name: string;
}
