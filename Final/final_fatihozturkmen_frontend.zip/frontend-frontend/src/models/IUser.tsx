export interface IUser {
    uid:      number;
    name:     string;
    surname:  string;
    age:      number;
    email:    string;
    password: string;
    roles:    number;
}
