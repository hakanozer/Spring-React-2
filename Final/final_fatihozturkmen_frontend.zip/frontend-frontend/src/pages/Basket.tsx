import React, { useEffect, useState } from 'react'

function Basket() {

    const [proArr, setProArr] = useState<string[]>([])
    useEffect(() => {
      const stArr = localStorage.getItem("basket")
      if(stArr) {
        const arr:string[] = JSON.parse(stArr) as string[]
        console.log('Arr : '+arr)
        setProArr(arr)
      }
    }, [])
    
    const fncDelete =(index: number) => {
        const newArr = Object.assign([],proArr)
        newArr.splice(index, 1)
        setProArr(newArr)
        localStorage.setItem("basket", JSON.stringify(newArr))
    }

  return (
    <>
        {proArr.map( (item, index) =>
            <>
            <h4 key={index}> {item} <span onClick={ () => fncDelete(index)} role='button' className='btn btn-danger' >Delete</span> </h4>
            
            </>
        )}
    </>
  )
}

export default Basket