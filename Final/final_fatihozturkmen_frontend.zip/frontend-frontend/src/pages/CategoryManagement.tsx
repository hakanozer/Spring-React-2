import React from 'react'
import { NavLink } from 'react-router-dom'

function CategoryManagement() {
  return (
    <>
    <h2 style={{marginTop:30}}>CategoryManagement</h2>

    <table className="table">
  <thead>
    <tr>
      <th scope="col">cid</th>
      <th scope="col">Name</th>
      
      <th scope="col">Delete</th>
      <th scope="col">Update</th>
      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td><button  type="button" className="btn btn-danger btn-sm">Delete</button></td>
      <td><button  type="button" className="btn btn-warning btn-sm">Update</button></td>
    </tr>
    
    
  </tbody>
</table>
    </>

    
  )
}

export default CategoryManagement