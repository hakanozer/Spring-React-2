import React from 'react'

function OrderManagement() {
  return (
    <div>OrderManagement</div>
  )
}

export default OrderManagement