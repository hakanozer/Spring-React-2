import React from 'react'

export default function ProductManagement() {
  return (
    <div>ProductManagement</div>
  )
}
