import React, { useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { IUser } from '../models/IUser';

function Navbar({ user }: { user: IUser }) {
  const navigate = useNavigate();

  const logout = () => {
    sessionStorage.removeItem('user');
    navigate('/');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container">
        <NavLink className="navbar-brand" to="/">
          E-Ticaret
        </NavLink>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <NavLink className="nav-link" to="/">
                Ana Sayfa
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to="/basket" className="nav-link">
                Profil
              </NavLink>
            </li>
            <li className="nav-item">
              <a className="nav-link disabled" aria-disabled="true">
                {user && user.email}
              </a>
            </li>
            <li className="nav-item dropdown">
              <a
                className="nav-link dropdown-toggle"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                Hesap
              </a>
              <ul className="dropdown-menu">
                <li>
                  <NavLink to="/login" className="dropdown-item">
                    Giriş Yap
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/register" className="dropdown-item">
                    Kayıt Ol
                  </NavLink>
                </li>
                <li>
                  <a
                    className="dropdown-item"
                    onClick={logout}
                    role="button"
                  >
                    Çıkış Yap
                  </a>
                </li>
                <li>
                  <NavLink to="/admin" className="dropdown-item">
                    Yönetici
                  </NavLink>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
