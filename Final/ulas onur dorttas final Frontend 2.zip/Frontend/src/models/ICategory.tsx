export interface ICategory {
    cid:  string;
    name: string;
}
