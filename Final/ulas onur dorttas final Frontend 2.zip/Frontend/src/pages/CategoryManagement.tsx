import React, { useEffect, useState } from 'react';
import { ICategory } from '../models/ICategory';
import { allCategories, categoryDelete, categorySave } from '../service';
import { toast } from 'react-toastify';
import { NavLink } from 'react-router-dom';

function CategoryManagement() {
  const [catArr, setCatArr] = useState<ICategory[]>([]);
  const [name, setName] = useState('');

  const sendForm = (evt: React.FormEvent) => {
    evt.preventDefault();
    categorySave(name)
      .then((res) => {
        toast.success('Kategori Başarıyla Kaydedildi!');
        window.location.reload();
      })
      .catch((err) => {
        console.log(err.message);
        toast.error('Yetkisiz Kullanıcı');
      });
  };

  useEffect(() => {
    allCategories()
      .then((res) => {
        setCatArr(res.data);
      })
      .catch((err) => {});
  }, []);

  const catDelete = (cid: string) => {
    categoryDelete(cid)
      .then((res) => {
        toast.success('Kategori Başarıyla Silindi!');
        window.location.reload();
      })
      .catch((err) => {
        toast.error('Yetkisiz Kullanıcı');
      });
  };

  return (
    <>
      <div style={{ marginTop: 50 }}>
        <NavLink to="/category-management" type="button" className="btn btn-primary btn-lg">
          Kategori Yönetimi
        </NavLink>
        <NavLink to="/product-management" style={{ marginLeft: 30 }} type="button" className="btn btn-warning btn-lg">
          Ürün Yönetimi
        </NavLink>
        <NavLink to="/order-management" style={{ marginLeft: 30 }} type="button" className="btn btn-secondary btn-lg">
          Sipariş Yönetimi
        </NavLink>
      </div>
      <h2 style={{ marginTop: 30 }}>Kategori Yönetimi</h2>

      <form onSubmit={sendForm} style={{ marginTop: 30 }} className="col-sm-5">
        <div className="mb-3">
          <input
            onChange={(evt) => setName(evt.target.value)}
            className="form-control"
            placeholder="Kategori Adı"
          />
        </div>
        <button className="btn btn-primary">Kategori Ekle</button>
      </form>

      <table style={{ marginTop: 20 }} className="table">
        <thead>
          <tr>
            <th scope="col">cid</th>
            <th scope="col">İsim</th>
            <th scope="col">Sil</th>
            <th scope="col">Güncelle</th>
          </tr>
        </thead>
        <tbody>
          {catArr.map((item, index) => (
            <tr key={index}>
              <th scope="row">{item.cid}</th>
              <td>{item.name}</td>
              <td>
                <button onClick={() => catDelete(item.cid)} type="button" className="btn btn-danger btn-sm">
                  Sil
                </button>
              </td>
              <td>
                <NavLink to={`/category-update/${item.cid}`} className="btn btn-warning btn-sm">
                  Güncelle
                </NavLink>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

export default CategoryManagement;
