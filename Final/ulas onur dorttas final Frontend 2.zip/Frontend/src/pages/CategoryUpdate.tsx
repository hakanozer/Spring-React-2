import React, { useEffect, useState } from 'react';
import { ICategory } from '../models/ICategory';
import { allCategories, categoryDelete, categoryUpdate } from '../service';
import { toast } from 'react-toastify';
import { NavLink } from 'react-router-dom';

function CategoryUpdate() {
  const [catArr, setCatArr] = useState<ICategory[]>([]);
  const [cid, setCid] = useState('');
  const [name, setName] = useState('');

  const sendForm = (evt: React.FormEvent) => {
    evt.preventDefault();
    categoryUpdate(cid, name)
      .then(() => {
        window.location.reload();
        toast.success('Kategori Güncelleme Başarılı!');
      })
      .catch((err) => {
        console.log(err.message);
        toast.error('Kategori Güncelleme Başarısız!');
      });
  };

  useEffect(() => {
    allCategories()
      .then((res) => {
        setCatArr(res.data);
      })
      .catch((err) => {});
  }, []);

  const catDelete = (cid: string) => {
    categoryDelete(cid)
      .then(() => {
        toast.success('Kategori Başarıyla Silindi!');
        window.location.reload();
      })
      .catch(() => {});
  };

  return (
    <>
      <div style={{ marginTop: 50 }}>
        <NavLink to="/category-management" type="button" className="btn btn-primary btn-lg">
          Kategori Yönetimi
        </NavLink>
        <NavLink to="/product-management" style={{ marginLeft: 30 }} type="button" className="btn btn-warning btn-lg">
          Ürün Yönetimi
        </NavLink>
        <NavLink to="/order-management" style={{ marginLeft: 30 }} type="button" className="btn btn-secondary btn-lg">
          Sipariş Yönetimi
        </NavLink>
      </div>
      <h2 style={{ marginTop: 30 }}>Kategori Güncelleme</h2>

      <form onSubmit={sendForm} style={{ marginTop: 30 }} className="col-sm-5">
        <div className="mb-3">
          <input
            onChange={(evt) => setCid(evt.target.value)}
            className="form-control"
            placeholder="Cid"
          />
          <input
            style={{ marginTop: 15 }}
            onChange={(evt) => setName(evt.target.value)}
            className="form-control"
            placeholder="Kategori Adı"
          />
        </div>
        <button className="btn btn-warning">Kategori Güncelle</button>
      </form>

      <table style={{ marginTop: 20 }} className="table">
        <thead>
          <tr>
            <th scope="col">cid</th>
            <th scope="col">İsim</th>
            <th scope="col">Sil</th>
            <th scope="col">Güncelle</th>
          </tr>
        </thead>
        <tbody>
          {catArr.map((item, index) => (
            <tr key={index}>
              <th scope="row">{item.cid}</th>
              <td>{item.name}</td>
              <td>
                <button onClick={() => catDelete(item.cid)} type="button" className="btn btn-danger btn-sm">
                  Sil
                </button>
              </td>
              <td>
                <NavLink to={`/category-update/${item.cid}`} className="btn btn-warning btn-sm">
                  Güncelle
                </NavLink>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

export default CategoryUpdate;
