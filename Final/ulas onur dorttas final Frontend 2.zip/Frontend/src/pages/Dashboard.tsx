import React from 'react';
import { NavLink } from 'react-router-dom';

export default function Dashboard() {
  const managementLinks = [
    { to: '/category-management', text: 'Category Management', color: 'primary' },
    { to: '/product-management', text: 'Product Management', color: 'warning' },
    { to: '/order-management', text: 'Order Management', color: 'secondary' },
  ];

  return (
    <>
      <h2 style={{ marginTop: 20 }}>Dashboard</h2>
      {managementLinks.map((link, index) => (
        <NavLink
          key={index}
          to={link.to}
          type="button"
          className={`btn btn-${link.color} btn-lg`}
          style={{ marginLeft: index !== 0 ? 30 : 0, marginTop: 10 }}
        >
          {link.text}
        </NavLink>
      ))}
    </>
  );
}
