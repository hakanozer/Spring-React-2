import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { addCard, singleProduct } from '../service';
import { Result } from '../models/Products';
import { IUser } from '../models/IUser';
import { toast } from 'react-toastify';
import { decrypt } from '../util';

function Detail() {
  const navigate = useNavigate();
  const params = useParams();
  const pid = params.pid;

  const [item, setItem] = useState<Result | null>(null);
  const [bigImage, setBigImage] = useState('');

  useEffect(() => {
    if (pid) {
      singleProduct(pid)
        .then((res) => {
          const product = res.data;
          setItem(product);
          setBigImage(product.images[0]);
        })
        .catch((err) => {
          navigate('/');
        });
    }
  }, [pid]);

  const [user, setUser] = useState<IUser | null>(null);

  useEffect(() => {
    const stSession = sessionStorage.getItem('user');
    if (stSession) {
      try {
        const plainText = decrypt(stSession);
        const parsedUser = JSON.parse(plainText) as IUser;
        setUser(parsedUser);
      } catch (error) {
        sessionStorage.removeItem('user');
        navigate('/login');
      }
    } else {
      navigate('/login');
    }
  }, []);

  const addBasket = () => {
    if (user && item) {
      addCard(user.email, pid!, item.title, item.price)
        .then(() => {
          toast.success('Added to Basket');
        })
        .catch((err) => {
          console.log(err.message);
        });

      addLocal(item.title, item.price);
    }
  };

  const addLocal = (title: string, price: string) => {
    const stObj = localStorage.getItem('basket');
    const newItem = `${title} - ${price}$`;

    if (stObj) {
      const stArr: string[] = JSON.parse(stObj) as string[];
      stArr.push(newItem);
      const st = JSON.stringify(stArr);
      localStorage.setItem('basket', st);
    } else {
      const arr: string[] = [newItem];
      const saveStr = JSON.stringify(arr);
      localStorage.setItem('basket', saveStr);
    }
  };

  return (
    <>
      {item && (
        <div className='row'>
          <div className='col-sm-6'>
            <h2 style={{ marginTop: 150 }}>{item.title}</h2>
            <p>{item.detail}</p>
            <p>{item.price}$</p>
            <button onClick={addBasket} className='btn btn-danger'>
              Add to Basket
            </button>
          </div>
          <div className='col-sm-6'>
            <img
              src={bigImage}
              className='img-fluid img-thumbnail'
              style={{ height: 400 }}
              alt={item.title}
            />
            <div className='row mt-3'>
              {item.images.map((image, index) => (
                <div
                  key={index}
                  className='col-3'
                  role='button'
                  onClick={() => setBigImage(image)}
                >
                  <img
                    src={image}
                    className='img-thumbnail'
                    style={{ height: 100 }}
                    alt={`Thumbnail ${index + 1}`}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default Detail;
