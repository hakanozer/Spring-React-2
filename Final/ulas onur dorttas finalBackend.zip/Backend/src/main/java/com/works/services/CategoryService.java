package com.works.services;

import com.works.configs.Rest;
import com.works.entities.Category;
import com.works.repositories.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public ResponseEntity<Rest> save(Category category) {
        try {
            Category savedCategory = categoryRepository.save(category);
            return ResponseEntity.ok(new Rest(true, savedCategory));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(new Rest(false, ex.getMessage()));
        }
    }

    public ResponseEntity<Rest> delete(Long cid) {
        try {
            categoryRepository.deleteById(cid);
            return ResponseEntity.ok(new Rest(true, cid));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(new Rest(false, ex.getMessage()));
        }
    }

    public ResponseEntity<Rest> update(Category category) {
        Optional<Category> optionalCategory = categoryRepository.findById(category.getCid());
        return optionalCategory.map(existingCategory -> {
            Category updatedCategory = categoryRepository.saveAndFlush(category);
            return ResponseEntity.ok(new Rest(true, updatedCategory));
        }).orElseGet(() -> ResponseEntity.badRequest().body(new Rest(false, category)));
    }

    public ResponseEntity<List<Category>> list() {
        List<Category> categoryList = categoryRepository.findAll();
        return ResponseEntity.ok(categoryList);
    }
}
