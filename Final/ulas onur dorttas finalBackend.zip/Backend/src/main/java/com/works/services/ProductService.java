package com.works.services;

import com.works.configs.Rest;
import com.works.entities.Product;
import com.works.repositories.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public ResponseEntity<Rest> save(Product product) {
        try {
            productRepository.save(product);
            return ResponseEntity.ok(new Rest(true, product));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(new Rest(false, ex.getMessage()));
        }
    }

    public ResponseEntity<Rest> delete(Long pid) {
        try {
            productRepository.deleteById(pid);
            return ResponseEntity.ok(new Rest(true, pid));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(new Rest(false, ex.getMessage()));
        }
    }

    public ResponseEntity<Rest> update(Product product) {
        Optional<Product> optionalProduct = productRepository.findById(product.getPid());
        if (optionalProduct.isPresent()) {
            productRepository.saveAndFlush(product);
            return ResponseEntity.ok(new Rest(true, product));
        }
        return ResponseEntity.badRequest().body(new Rest(false, product));
    }

    public ResponseEntity<Rest> list() {
        List<Product> productList = productRepository.findAll();
        return ResponseEntity.ok(new Rest(true, productList));
    }

    public ResponseEntity<Product> getSingleProduct(Long pid) {
        Optional<Product> optionalProduct = productRepository.findById(pid);
        return optionalProduct.map(product -> ResponseEntity.ok().body(product))
                .orElseGet(() -> ResponseEntity.badRequest().body(null));
    }

    public ResponseEntity<Rest> getCategoryProduct(String name) {
        List<Product> productList = productRepository.findByCategories_NameEquals(name);
        return ResponseEntity.ok(new Rest(true, productList));
    }
}
