package com.example.productmanagementandpromotionwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementAndPromotionWebAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductManagementAndPromotionWebAppApplication.class, args);
    }

}
