package com.work;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VizeApplication {

	public static void main(String[] args) {
		SpringApplication.run(VizeApplication.class, args);
	}

}
