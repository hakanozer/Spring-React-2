package com.work.vize;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VizeApplicationTests {

	@Test
	void contextLoads() {
	}

}
