package com.works.controllers;

import com.works.props.Product;
import com.works.services.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class HomeController {
    int status=1;
    String message="";
    int id=0;
    ProductService service = new ProductService();

    @GetMapping("/")
    public String Home(Model model, @RequestParam(defaultValue = "1") int n) {
        model.addAttribute("products", service.products(n));
        int count = service.totalCount();
        model.addAttribute("count", service.totalCount());
        int page = count % 10 == 0 ? count / 10 : (count / 10) + 1;
        model.addAttribute("page", page);
        model.addAttribute("n", n);


        return "Home";
    }

    @GetMapping("/info/{id}")
    public String info(@PathVariable int id, Model model) {
        Product p = service.single(id);
        model.addAttribute("product", p);


        return "info";
    }


    @GetMapping("/Dashboard")
    public String Dashboard(Model model, @RequestParam(defaultValue = "1") int n) {
        model.addAttribute("products", service.products(n));
        int count = service.totalCount();
        model.addAttribute("count", service.totalCount());
        int page = count % 10 == 0 ? count / 10 : (count / 10) + 1;
        model.addAttribute("page", page);
        model.addAttribute("n", n);
        return "Dashboard";

    }

    @GetMapping("/productDelete/{id}")
    public String productDelete(@PathVariable int id) {
        status = service.deleteproduct(id);
        if (status > 0) {

            this.id = id;

        }
        return "redirect:/Dashboard";
    }
}