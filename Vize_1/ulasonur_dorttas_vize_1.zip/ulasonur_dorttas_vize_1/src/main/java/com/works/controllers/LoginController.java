package com.works.controllers;

import com.works.props.Product;
import com.works.props.User;
import com.works.services.ProductService;
import com.works.services.UserService;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
@Controller
public class LoginController {
    UserService userService = new UserService();

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/userLogin")
    public String userLogin(User user, HttpServletRequest request) {
        User u = userService.loginUser(user);
        if (u != null) {

            String sessionID = generateSessionID();

            request.setAttribute("sessionID", sessionID);

            request.getSession().setAttribute(sessionID, u);
            return "redirect:/home";
        }
        return "redirect:/";
    }

    // Oturum kimliği oluşturmak için kullanılacak yöntem
    private String generateSessionID() {

        return "sample-session-id";
    }
}
