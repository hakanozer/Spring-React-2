package com.works.controllers;

import com.works.props.Product;
import com.works.services.searchService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class SearchController {
    searchService service =new searchService();

    @GetMapping("/search")
    public String search(@RequestParam("q") String q, Model model) {
        List<Product> products = service.search(q);
        model.addAttribute("products", products);
        return "search";
    }

}
