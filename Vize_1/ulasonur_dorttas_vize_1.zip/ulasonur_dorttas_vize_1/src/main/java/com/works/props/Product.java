package com.works.props;

import lombok.Data;

@Data
public class Product {
    private int id;
    private String marka;
    private String model;
    private String donanim;
    private String motor;
    private String yakit;
    private String vites;
    private int fiyat;
    private String websitesi;


}
