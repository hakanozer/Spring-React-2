package com.works.props;

import lombok.Data;

@Data
public class User {
    private String Email;
    private String Password;
}
