package com.works.services;

import com.works.props.Product;
import com.works.props.User;
import com.works.utils.DB;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    public List<Product> products(int n){
        List<Product> ls= new ArrayList<>();
        DB db = new DB();

        try {
            n=(n-1)*10;

            String sql="select * from otomobil_fiyatlari limit ?,10";
            PreparedStatement pre= db.connet().prepareStatement(sql);
            pre.setInt(1,n);
            ResultSet rs= pre.executeQuery();
            while (rs.next()){
                Product p= new Product();
                p.setId(rs.getInt("id"));
                p.setMarka(rs.getString("marka"));
                p.setModel(rs.getString("model"));
                p.setMotor(rs.getString("motor"));
                p.setDonanim(rs.getString("donanim"));
                p.setFiyat(rs.getInt("fiyat"));
                p.setVites(rs.getString("vites"));
                p.setWebsitesi(rs.getString("websitesi"));
                ls.add(p);
            }
        }catch (Exception ex){
            System.err.println("error"+ex);
        }
            finally{ db.close();}
        return ls;
    }
    public  int totalCount (){
        int count=0;
        DB db = new DB();
        try {
            String sql="select count(id) as count from otomobil_fiyatlari";
            PreparedStatement pre = db.connet().prepareStatement(sql);
            ResultSet rs = pre.executeQuery();
            if(rs.next()){
                count=rs.getInt("count");
            }

        }catch (Exception ex){
            System.err.println("error"+ex);
        }finally {
            db.close();
        }
        return count;
    }


    public Product single(int id){
        DB db=new DB();
        Product p= new Product();
        try {
            String sql="select * from otomobil_fiyatlari where id=?";
            PreparedStatement pre= db.connet().prepareStatement(sql);
            pre.setInt(1,id);
            ResultSet rs=pre.executeQuery();
            if (rs.next()){
                p.setId(rs.getInt("id"));
                p.setMarka(rs.getString("marka"));
                p.setModel(rs.getString("model"));
                p.setMotor(rs.getString("motor"));
                p.setDonanim(rs.getString("donanim"));
                p.setFiyat(rs.getInt("fiyat"));
                p.setVites(rs.getString("vites"));
                p.setWebsitesi(rs.getString("websitesi"));
                p.setYakit(rs.getString("yakit"));
            }
        }catch (Exception ex){
            System.err.println("error"+ex);
        }finally {
            db.close();
        }
        return p;
    }
    public int deleteproduct(int uid) {
        int status = 1;
        DB db = new DB();
        try {
            String sql = "delete from otomobil_fiyatlari where uid = ?";

            PreparedStatement pre = db.connet().prepareStatement(sql);

            pre.setInt(1,uid);
            status = pre.executeUpdate();
        } catch (Exception ex) {
            System.out.println(ex);
        } finally {
            db.close();
        }
        return status;
    }
    }






