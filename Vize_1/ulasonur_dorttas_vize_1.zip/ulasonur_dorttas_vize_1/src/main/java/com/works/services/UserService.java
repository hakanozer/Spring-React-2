package com.works.services;

import com.works.props.Product;
import com.works.props.User;
import com.works.utils.DB;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserService {
    public User loginUser (User user){
        User u=null;
        DB db =new DB();
        try {
            String sql="select * from user where email=? and password=?";
            PreparedStatement pre= db.connet().prepareStatement(sql);
            pre.setString(1,user.getEmail());
            pre.setString(2, user.getPassword());
            ResultSet rs= pre.executeQuery();
            if(rs.next()){
                u=new User();
                u.setEmail(rs.getString("email"));
                u.setPassword(rs.getString("password"));


            }
        }catch (Exception ex){

        }finally {
            db.close();
        }
        return u;}
}
