package com.works.services;

import com.works.props.Product;
import com.works.utils.DB;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class searchService {


    public List<Product> search(String q){
        List<Product> ls= new ArrayList<>();
        DB db = new DB();
        try {
            String sql="select * from otomobil_fiyatlari where marka like ? or model like ? or donanim like ?";
            PreparedStatement pre =db.connet().prepareStatement(sql);
            pre.setString(1,"%"+q+"%");
            pre.setString(2,"%"+q+"%");
            pre.setString(3,"%"+q+"%");
            ResultSet rs= pre.executeQuery();
            while (rs.next()){
                Product p= new Product();
                p.setId(rs.getInt("id"));
                p.setMarka(rs.getString("marka"));
                p.setModel(rs.getString("model"));
                p.setMotor(rs.getString("motor"));
                p.setDonanim(rs.getString("donanim"));
                p.setFiyat(rs.getInt("fiyat"));
                p.setVites(rs.getString("vites"));
                p.setWebsitesi(rs.getString("websitesi"));
                ls.add(p);
            }


        }catch (Exception ex){
            System.err.println("error"+ex);
        } finally {
            {db.close();
            }
            return ls;
        }
    }}

