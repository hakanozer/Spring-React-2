package com.works.utils;
import java.sql.Connection;
import java.sql.DriverManager;

public class DB {
    private final String driver= "com.mysql.cj.jdbc.Driver";
    private final String url= "jdbc:mysql://localhost:8889/vize";
    private final String username="root";
    private final String password="root";
    private Connection conn= null;
    public  Connection connet(){
        try {
            if (conn ==null || conn.isClosed()){
                Class.forName(driver);
                conn= DriverManager.getConnection(url,username,password);
                System.out.println("Connetcin Success");}
        } catch (Exception ex){
            System.err.println("error:"+ex);
        }
        return conn;
    }
    public void close(){
        try{
            if (conn !=null && !conn.isClosed()){
                conn.close();
                System.out.println("Connection close");
            }

        } catch (Exception ex){
            System.out.println("close error :"+ex);
        }
    }
}

