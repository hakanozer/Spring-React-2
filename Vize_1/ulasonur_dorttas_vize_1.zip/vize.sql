-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:8889
-- Üretim Zamanı: 03 Haz 2023, 17:39:50
-- Sunucu sürümü: 5.7.39
-- PHP Sürümü: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `vize`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `otomobil_fiyatlari`
--

CREATE TABLE `otomobil_fiyatlari` (
  `id` int(11) NOT NULL,
  `marka` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `model` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `donanim` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `motor` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `yakit` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `vites` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `fiyat` int(11) NOT NULL,
  `websitesi` varchar(50) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `otomobil_fiyatlari`
--

INSERT INTO `otomobil_fiyatlari` (`id`, `marka`, `model`, `donanim`, `motor`, `yakit`, `vites`, `fiyat`, `websitesi`) VALUES
(1, 'Alfa Romeo', '4C', '1.8 TCT', '1800', 'Benzin', 'Otomatik', 580000, 'http://www.alfaromeo.com.tr/'),
(2, 'Alfa Romeo', '4C Spider', '1.8 TCT', '1800', 'Benzin', 'Otomatik', 620000, 'http://www.alfaromeo.com.tr/'),
(3, 'Alfa Romeo', 'Giulia', '2.0 200hp SUPER RWD BENZİNLİ AT', '2000', 'Benzin', 'Otomatik', 320000, 'http://www.alfaromeo.com.tr/'),
(4, 'Alfa Romeo', 'Giulia', '2.0 280hp VELOCE AWD BENZİNLİ AT', '2000', 'Benzin', 'Otomatik', 380000, 'http://www.alfaromeo.com.tr/'),
(5, 'Alfa Romeo', 'Giulia', '2.9 510hp QV RWD BENZİNLİ AT', '2900', 'Benzin', 'Otomatik', 780000, 'http://www.alfaromeo.com.tr/'),
(6, 'Alfa Romeo', 'Giulietta', '1.4 TB MULTIAIR SUPER BENZİNLİ TCT', '1400', 'Benzin', 'Otomatik', 121000, 'http://www.alfaromeo.com.tr/'),
(7, 'Alfa Romeo', 'Giulietta', '1.6 JTD 120hp PROGRESSION DİZEL MT', '1600', 'Dizel', 'Düz', 114000, 'http://www.alfaromeo.com.tr/'),
(8, 'Alfa Romeo', 'Giulietta', '1.6 JTD 120hp SUPER DİZEL MT', '1600', 'Dizel', 'Düz', 121000, 'http://www.alfaromeo.com.tr/'),
(9, 'Alfa Romeo', 'Giulietta', '1.6 JTDM 120hp SUPER DİZEL TCT', '1600', 'Dizel', 'Otomatik', 136000, 'http://www.alfaromeo.com.tr/'),
(10, 'Alfa Romeo', 'Giulietta', '1.6 JTDM PROGRESSION DİZEL TCT', '1600', 'Dizel', 'Otomatik', 121000, 'http://www.alfaromeo.com.tr/'),
(11, 'Audi', 'A1 Sportback', '1.0 TFSI 95 hp Dynamic S tronic', '1000', 'Benzin', 'Otomatik', 110271, 'http://www.audi.com.tr/'),
(12, 'Audi', 'A1 Sportback', '1.0 TFSI 95 hp Sport S tronic', '1000', 'Benzin', 'Otomatik', 112661, 'http://www.audi.com.tr/'),
(13, 'Audi', 'A1 Sportback', '1.4 TFSI 125 hp Dynamic S tronic', '1400', 'Benzin', 'Otomatik', 114973, 'http://www.audi.com.tr/'),
(14, 'Audi', 'A1 Sportback', '1.4 TFSI 125 hp Sport S tronic ', '1400', 'Benzin', 'Otomatik', 117406, 'http://www.audi.com.tr/'),
(15, 'Audi', 'A1 Sportback', '1.6 TDI 116 hp Dynamic S tronic ', '1600', 'Dizel', 'Otomatik', 122755, 'http://www.audi.com.tr/'),
(16, 'Audi', 'A1 Sportback', '1.6 TDI 116 hp Sport S tronic ', '1600', 'Dizel', 'Otomatik', 133425, 'http://www.audi.com.tr/'),
(17, 'Audi', 'A3 Cabrio', '1.4 TFSI 150 hp (COD) Design Line S tronic PI', '1400', 'Benzin', 'Otomatik', 189127, 'http://www.audi.com.tr/'),
(18, 'Audi', 'A3 Cabrio', '1.4 TFSI 150 hp (COD) Dynamic S tronic PI', '1400', 'Benzin', 'Otomatik', 181567, 'http://www.audi.com.tr/'),
(19, 'Audi', 'A3 Cabrio', '1.4 TFSI 150 hp (COD) Sport Line S tronic PI', '1400', 'Benzin', 'Otomatik', 189216, 'http://www.audi.com.tr/'),
(20, 'Audi', 'A3 Sedan', '1.0 TFSI 116 hp Design Line S tronic PI', '1000', 'Benzin', 'Otomatik', 157032, 'http://www.audi.com.tr/'),
(21, 'Audi', 'A3 Sedan', '1.0 TFSI 116 hp Dynamic S tronic PI', '1000', 'Benzin', 'Otomatik', 149464, 'http://www.audi.com.tr/'),
(22, 'Audi', 'A3 Sedan', '1.0 TFSI 116 hp Sport Line S tronic PI', '1000', 'Benzin', 'Otomatik', 157114, 'http://www.audi.com.tr/'),
(23, 'Audi', 'A3 Sedan', '1.4 TFSI 150 hp (COD) Design Line S tronic PI', '1400', 'Benzin', 'Otomatik', 171210, 'http://www.audi.com.tr/'),
(24, 'Audi', 'A3 Sedan', '1.4 TFSI 150 hp (COD) Dynamic S tronic PI', '1400', 'Benzin', 'Otomatik', 163650, 'http://www.audi.com.tr/'),
(25, 'Audi', 'A3 Sedan', '1.4 TFSI 150 hp (COD) Sport Line S tronic PI', '1400', 'Benzin', 'Otomatik', 171292, 'http://www.audi.com.tr/'),
(26, 'Audi', 'A3 Sedan', '1.6 TDI 110 hp Design Line S tronic PI', '1600', 'Dizel', 'Otomatik', 176452, 'http://www.audi.com.tr/'),
(27, 'Audi', 'A3 Sedan', '1.6 TDI 110 hp Dynamic S tronic PI', '1600', 'Dizel', 'Otomatik', 168892, 'http://www.audi.com.tr/'),
(28, 'Audi', 'A3 Sedan', '1.6 TDI 110 hp Sport Line S tronic PI ', '1600', 'Dizel', 'Otomatik', 176542, 'http://www.audi.com.tr/'),
(29, 'Audi', 'A3 Sedan', '1.6 TDI 116 hp Design Line S tronic PI', '1600', 'Dizel', 'Otomatik', 176452, 'http://www.audi.com.tr/'),
(30, 'Audi', 'A3 Sedan', '1.6 TDI 116 hp Dynamic S tronic PI', '1600', 'Dizel', 'Otomatik', 168892, 'http://www.audi.com.tr/'),
(31, 'Audi', 'A3 Sedan', '1.6 TDI 116 hp Sport Line S tronic PI', '1600', 'Dizel', 'Otomatik', 176542, 'http://www.audi.com.tr/'),
(32, 'Audi', 'A3 Sportback', '1.0 TFSI 116 hp Design Line S tronic PI', '1000', 'Benzin', 'Otomatik', 152224, 'http://www.audi.com.tr/'),
(33, 'Audi', 'A3 Sportback', '1.0 TFSI 116 hp Dynamic S tronic PI', '1000', 'Benzin', 'Otomatik', 144664, 'http://www.audi.com.tr/'),
(34, 'Audi', 'A3 Sportback', '1.0 TFSI 116 hp Sport Line S tronic PI', '1000', 'Benzin', 'Otomatik', 152306, 'http://www.audi.com.tr/'),
(35, 'Audi', 'A3 Sportback', '1.4 TFSI 150 hp (COD) Design Line S tronic PI', '1400', 'Benzin', 'Otomatik', 166402, 'http://www.audi.com.tr/'),
(36, 'Audi', 'A3 Sportback', '1.4 TFSI 150 hp (COD) Dynamic S tronic PI', '1400', 'Benzin', 'Otomatik', 158842, 'http://www.audi.com.tr/'),
(37, 'Audi', 'A3 Sportback', '1.4 TFSI 150 hp (COD) Sport Line S tronic PI', '1400', 'Benzin', 'Otomatik', 166491, 'http://www.audi.com.tr/'),
(38, 'Audi', 'A3 Sportback', '1.6 TDI 110 hp Design Line S tronic PI', '1600', 'Dizel', 'Otomatik', 171644, 'http://www.audi.com.tr/'),
(39, 'Audi', 'A3 Sportback', '1.6 TDI 110 hp Dynamic S tronic PI', '1600', 'Dizel', 'Otomatik', 164084, 'http://www.audi.com.tr/'),
(40, 'Audi', 'A3 Sportback', '1.6 TDI 110 hp Sport Line S tronic PI ', '1600', 'Dizel', 'Otomatik', 171733, 'http://www.audi.com.tr/'),
(41, 'Audi', 'A3 Sportback', '1.6 TDI 116 hp Design Line S tronic PI', '1600', 'Dizel', 'Otomatik', 171644, 'http://www.audi.com.tr/'),
(42, 'Audi', 'A3 Sportback', '1.6 TDI 116 hp Dynamic S tronic PI', '1600', 'Dizel', 'Otomatik', 164084, 'http://www.audi.com.tr/'),
(43, 'Audi', 'A3 Sportback', '1.6 TDI 116 hp Sport Line S tronic PI', '1600', 'Dizel', 'Otomatik', 171733, 'http://www.audi.com.tr/'),
(44, 'Audi', 'A4', '1.4 TFSI 150 hp Design S tronic', '1400', 'Benzin', 'Otomatik', 215217, 'http://www.audi.com.tr/'),
(45, 'Audi', 'A4', '1.4 TFSI 150 hp Dynamic S tronic', '1400', 'Benzin', 'Otomatik', 193800, 'http://www.audi.com.tr/'),
(46, 'Audi', 'A4', '1.4 TFSI 150 hp Sport S tronic', '1400', 'Benzin', 'Otomatik', 230075, 'http://www.audi.com.tr/'),
(47, 'Audi', 'A4', '2.0 TDI 190 hp Design S tronic', '2000', 'Dizel', 'Otomatik', 279095, 'http://www.audi.com.tr/'),
(48, 'Audi', 'A4', '2.0 TDI 190 hp Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 258082, 'http://www.audi.com.tr/'),
(49, 'Audi', 'A4', '2.0 TDI 190 hp quattro Design S tronic', '2000', 'Dizel', 'Otomatik', 296604, 'http://www.audi.com.tr/'),
(50, 'Audi', 'A4', '2.0 TDI 190 hp quattro Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 275591, 'http://www.audi.com.tr/'),
(51, 'Audi', 'A4', '2.0 TDI 190 hp quattro Sport S tronic', '2000', 'Dizel', 'Otomatik', 318491, 'http://www.audi.com.tr/'),
(52, 'Audi', 'A4', '2.0 TDI 190 hp Sport S tronic', '2000', 'Dizel', 'Otomatik', 300981, 'http://www.audi.com.tr/'),
(53, 'Audi', 'A4', '2.0 TFSI 252 hp quattro Design S tronic', '2000', 'Benzin', 'Otomatik', 343008, 'http://www.audi.com.tr/'),
(54, 'Audi', 'A4', '2.0 TFSI 252 hp quattro Dynamic S tronic', '2000', 'Benzin', 'Otomatik', 321995, 'http://www.audi.com.tr/'),
(55, 'Audi', 'A4', '2.0 TFSI 252 hp quattro Sport S tronic', '2000', 'Benzin', 'Otomatik', 364894, 'http://www.audi.com.tr/'),
(56, 'Audi', 'A4 Allroad', '2.0 TDI quattro 190 hp S tronic', '2000', 'Dizel', 'Otomatik', 309334, 'http://www.audi.com.tr/'),
(57, 'Audi', 'A4 Allroad', '2.0 TFSI quattro 252 hp S tronic', '2000', 'Benzin', 'Otomatik', 355727, 'http://www.audi.com.tr/'),
(58, 'Audi', 'A4 Avant', '1.4 TFSI 150 hp Design S tronic', '1400', 'Benzin', 'Otomatik', 227862, 'http://www.audi.com.tr/'),
(59, 'Audi', 'A4 Avant', '1.4 TFSI 150 hp Dynamic S tronic', '1400', 'Benzin', 'Otomatik', 204112, 'http://www.audi.com.tr/'),
(60, 'Audi', 'A4 Avant', '1.4 TFSI 150 hp Sport S tronic', '1400', 'Benzin', 'Otomatik', 242720, 'http://www.audi.com.tr/'),
(61, 'Audi', 'A4 Avant', '2.0 TDI 190 hp Design S tronic', '2000', 'Dizel', 'Otomatik', 295682, 'http://www.audi.com.tr/'),
(62, 'Audi', 'A4 Avant', '2.0 TDI 190 hp Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 271606, 'http://www.audi.com.tr/'),
(63, 'Audi', 'A4 Avant', '2.0 TDI 190 hp quattro Design S tronic', '2000', 'Dizel', 'Otomatik', 313191, 'http://www.audi.com.tr/'),
(64, 'Audi', 'A4 Avant', '2.0 TDI 190 hp quattro Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 289116, 'http://www.audi.com.tr/'),
(65, 'Audi', 'A4 Avant', '2.0 TDI 190 hp quattro Sport S tronic', '2000', 'Dizel', 'Otomatik', 335077, 'http://www.audi.com.tr/'),
(66, 'Audi', 'A4 Avant', '2.0 TDI 190 hp Sport S tronic', '2000', 'Dizel', 'Otomatik', 317568, 'http://www.audi.com.tr/'),
(67, 'Audi', 'A4 Avant', '2.0 TFSI 252 hp quattro Design S tronic', '2000', 'Benzin', 'Otomatik', 359594, 'http://www.audi.com.tr/'),
(68, 'Audi', 'A4 Avant', '2.0 TFSI 252 hp quattro Dynamic S tronic', '2000', 'Benzin', 'Otomatik', 335519, 'http://www.audi.com.tr/'),
(69, 'Audi', 'A4 Avant', '2.0 TFSI 252 hp quattro Sport S tronic', '2000', 'Benzin', 'Otomatik', 381481, 'http://www.audi.com.tr/'),
(70, 'Audi', 'A5 Coupe', '1.4 TFSI 150 hp Design S tronic', '1400', 'Benzin', 'Otomatik', 219464, 'http://www.audi.com.tr/'),
(71, 'Audi', 'A5 Coupe', '1.4 TFSI 150 hp Dynamic S tronic', '1400', 'Benzin', 'Otomatik', 212158, 'http://www.audi.com.tr/'),
(72, 'Audi', 'A5 Coupe', '1.4 TFSI 150 hp Sport S tronic', '1400', 'Benzin', 'Otomatik', 224796, 'http://www.audi.com.tr/'),
(73, 'Audi', 'A5 Coupe', '2.0 TDI 190 hp Design S tronic', '2000', 'Dizel', 'Otomatik', 311012, 'http://www.audi.com.tr/'),
(74, 'Audi', 'A5 Coupe', '2.0 TDI 190 hp Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 301413, 'http://www.audi.com.tr/'),
(75, 'Audi', 'A5 Coupe', '2.0 TDI 190 hp quattro Design S tronic', '2000', 'Dizel', 'Otomatik', 328520, 'http://www.audi.com.tr/'),
(76, 'Audi', 'A5 Coupe', '2.0 TDI 190 hp quattro Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 318932, 'http://www.audi.com.tr/'),
(77, 'Audi', 'A5 Coupe', '2.0 TDI 190 hp quattro Sport S tronic', '2000', 'Dizel', 'Otomatik', 335519, 'http://www.audi.com.tr/'),
(78, 'Audi', 'A5 Coupe', '2.0 TDI 190 hp Sport S tronic', '2000', 'Dizel', 'Otomatik', 318010, 'http://www.audi.com.tr/'),
(79, 'Audi', 'A5 Coupe', '2.0 TFSI 252 hp quattro Design S tronic', '2000', 'Benzin', 'Otomatik', 351998, 'http://www.audi.com.tr/'),
(80, 'Audi', 'A5 Coupe', '2.0 TFSI 252 hp quattro Dynamic S tronic', '2000', 'Benzin', 'Otomatik', 342409, 'http://www.audi.com.tr/'),
(81, 'Audi', 'A5 Coupe', '2.0 TFSI 252 hp quattro Sport S tronic', '2000', 'Benzin', 'Otomatik', 356807, 'http://www.audi.com.tr/'),
(82, 'Audi', 'A5 Sportback', '1.4 TFSI 150 hp Design S tronic', '1400', 'Benzin', 'Otomatik', 219464, 'http://www.audi.com.tr/'),
(83, 'Audi', 'A5 Sportback', '1.4 TFSI 150 hp Dynamic S tronic', '1400', 'Benzin', 'Otomatik', 212158, 'http://www.audi.com.tr/'),
(84, 'Audi', 'A5 Sportback', '1.4 TFSI 150 hp Sport S tronic', '1400', 'Benzin', 'Otomatik', 223128, 'http://www.audi.com.tr/'),
(85, 'Audi', 'A5 Sportback', '2.0 TDI 190 hp  Sport S tronic', '2000', 'Dizel', 'Otomatik', 315821, 'http://www.audi.com.tr/'),
(86, 'Audi', 'A5 Sportback', '2.0 TDI 190 hp Design S tronic', '2000', 'Dizel', 'Otomatik', 311012, 'http://www.audi.com.tr/'),
(87, 'Audi', 'A5 Sportback', '2.0 TDI 190 hp Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 301413, 'http://www.audi.com.tr/'),
(88, 'Audi', 'A5 Sportback', '2.0 TDI 190 hp quattro Design S tronic', '2000', 'Dizel', 'Otomatik', 328520, 'http://www.audi.com.tr/'),
(89, 'Audi', 'A5 Sportback', '2.0 TDI 190 hp quattro Dynamic S tronic', '2000', 'Dizel', 'Otomatik', 318932, 'http://www.audi.com.tr/'),
(90, 'Audi', 'A5 Sportback', '2.0 TDI 190 hp quattro Sport S tronic', '2000', 'Dizel', 'Otomatik', 333330, 'http://www.audi.com.tr/'),
(91, 'Audi', 'A5 Sportback', '2.0 TFSI 252 hp quattro Design S tronic', '2000', 'Benzin', 'Otomatik', 351998, 'http://www.audi.com.tr/'),
(92, 'Audi', 'A5 Sportback', '2.0 TFSI 252 hp quattro Dynamic S tronic', '2000', 'Benzin', 'Otomatik', 342409, 'http://www.audi.com.tr/'),
(93, 'Audi', 'A5 Sportback', '2.0 TFSI 252 hp quattro Sport S tronic', '2000', 'Benzin', 'Otomatik', 356807, 'http://www.audi.com.tr/'),
(94, 'Audi', 'A6', '2.0 TDI 190 hp quattro S tronic ', '2000', 'Dizel', 'Otomatik', 384366, 'http://www.audi.com.tr/'),
(95, 'Audi', 'A6', '2.0 TDI 190 hp S tronic ', '2000', 'Dizel', 'Otomatik', 359202, 'http://www.audi.com.tr/'),
(96, 'Audi', 'A6', '3.0 TDI 272 hp quattro S tronic ', '3000', 'Dizel', 'Otomatik', 499119, 'http://www.audi.com.tr/'),
(97, 'Audi', 'A6', '3.0 TDI 320 hp quattro tiptronic', '3000', 'Dizel', 'Otomatik', 566365, 'http://www.audi.com.tr/'),
(98, 'Audi', 'A6 Allroad', '3.0 TDI 272 hp quattro S tronic', '3000', 'Dizel', 'Otomatik', 571639, 'http://www.audi.com.tr/'),
(99, 'Audi', 'A6 Allroad', '3.0 TDI 320 hp quattro tiptronic', '3000', 'Dizel', 'Otomatik', 638885, 'http://www.audi.com.tr/'),
(100, 'Audi', 'A6 Avant', '2.0 TDI 190 hp quattro S tronic', '2000', 'Dizel', 'Otomatik', 400472, 'http://www.audi.com.tr/'),
(101, 'Audi', 'A6 Avant', '2.0 TDI 190 hp S tronic', '2000', 'Dizel', 'Otomatik', 375307, 'http://www.audi.com.tr/'),
(102, 'Audi', 'A7 Sportback', '2.0 TFSI 252 hp quattro S tronic', '2000', 'Benzin', 'Otomatik', 466456, 'http://www.audi.com.tr/'),
(103, 'Audi', 'A7 Sportback', '3.0 TDI 272 hp quattro S tronic', '3000', 'Dizel', 'Otomatik', 632359, 'http://www.audi.com.tr/'),
(104, 'Audi', 'A7 Sportback', '3.0 TDI 320 hp quattro tiptronic', '3000', 'Dizel', 'Otomatik', 691622, 'http://www.audi.com.tr/'),
(105, 'Audi', 'A8 L', '2.0 TFSI 252 hp quattro tiptronic', '2000', 'Benzin', 'Otomatik', 770257, 'http://www.audi.com.tr/'),
(106, 'Audi', 'A8 L', '3.0 TDI 262 hp quattro tiptronic', '3000', 'Dizel', 'Otomatik', 965248, 'http://www.audi.com.tr/'),
(107, 'Audi', 'A8 L', '4.0 TFSI 435 hp quattro tiptronic', '4000', 'Benzin', 'Otomatik', 1181705, 'http://www.audi.com.tr/'),
(108, 'Audi', 'A8 L', '4.2 TDI 385 hp quattro tiptronic', '4200', 'Dizel', 'Otomatik', 1128707, 'http://www.audi.com.tr/'),
(109, 'Audi', 'A8 L W12', '6.3 FSI 500 hp quattro tiptronic', '6300', 'Benzin', 'Otomatik', 1643186, 'http://www.audi.com.tr/'),
(110, 'Audi', 'Q2', '1.4 Turbo FSI 150 hp (COD) Design S tronic', '1400', 'Benzin', 'Otomatik', 153638, 'http://www.audi.com.tr/'),
(111, 'Audi', 'Q2', '1.4 Turbo FSI 150 hp (COD) Dynamic S tronic', '1400', 'Benzin', 'Otomatik', 149661, 'http://www.audi.com.tr/'),
(112, 'Audi', 'Q2', '1.4 Turbo FSI 150 hp (COD) Sport S tronic', '1400', 'Benzin', 'Otomatik', 153638, 'http://www.audi.com.tr/'),
(113, 'Audi', 'Q2', '1.6 TDI 116 hp Design S tronic', '1600', 'Dizel', 'Otomatik', 161945, 'http://www.audi.com.tr/'),
(114, 'Audi', 'Q2', '1.6 TDI 116 hp Dynamic S tronic', '1600', 'Dizel', 'Otomatik', 157967, 'http://www.audi.com.tr/'),
(115, 'Audi', 'Q2', '1.6 TDI 116 hp Sport S tronic', '1600', 'Dizel', 'Otomatik', 161945, 'http://www.audi.com.tr/'),
(116, 'Audi', 'Q3', '1.4 TFSI 150 hp (COD) S tronic', '1400', 'Benzin', 'Otomatik', 186592, 'http://www.audi.com.tr/'),
(117, 'Audi', 'Q3', '2.0 TDI 184 hp quattro S tronic', '2000', 'Dizel', 'Otomatik', 282815, 'http://www.audi.com.tr/'),
(118, 'Audi', 'Q5', '2.0 TDI 190 hp quattro Design S tronic', '2000', 'Dizel', 'Otomatik', 373992, 'http://www.audi.com.tr/'),
(119, 'Audi', 'Q5', '2.0 TDI 190 hp quattro S tronic', '2000', 'Dizel', 'Otomatik', 373992, 'http://www.audi.com.tr/'),
(120, 'Audi', 'Q5', '2.0 TFSI 230 hp quattro tiptronic', '2000', 'Benzin', 'Otomatik', 363599, 'http://www.audi.com.tr/'),
(121, 'Audi', 'Q7', '2.0 TFSI 252 hp quattro tiptronic', '2000', 'Benzin', 'Otomatik', 486154, 'http://www.audi.com.tr/'),
(122, 'Audi', 'Q7', '3.0 TDI 272 hp quattro tiptronic', '3000', 'Dizel', 'Otomatik', 683638, 'http://www.audi.com.tr/'),
(123, 'Audi', 'R8 Coupe', '5.2 FSI V10 plus quattro S tronic', '5200', 'Benzin', 'Otomatik', 1981543, 'http://www.audi.com.tr/'),
(124, 'Audi', 'R8 Coupe', '5.2 FSI V10 quattro S tronic', '5200', 'Benzin', 'Otomatik', 1756668, 'http://www.audi.com.tr/'),
(125, 'Audi', 'RS 6 Avant', '4.0 TFSI 560 hp quattro tiptronic', '4000', 'Benzin', 'Otomatik', 1072002, 'http://www.audi.com.tr/'),
(126, 'Audi', 'RS 6 Avant', '4.0 TFSI 605 hp performance quattro tiptronic', '4000', 'Benzin', 'Otomatik', 1136307, 'http://www.audi.com.tr/'),
(127, 'Audi', 'RS 7 Sportback', '4.0 TFSI 560 hp quattro tiptronic', '4000', 'Benzin', 'Otomatik', 1135043, 'http://www.audi.com.tr/'),
(128, 'Audi', 'RS 7 Sportback', '4.0 TFSI 605 hp performance quattro tiptronic', '4000', 'Benzin', 'Otomatik', 1200199, 'http://www.audi.com.tr/'),
(129, 'Audi', 'S8', '4.0 TFSI 520 hp quattro tiptronic', '4000', 'Benzin', 'Otomatik', 1271650, 'http://www.audi.com.tr/'),
(130, 'Audi', 'S8', '4.0 TFSI 605 hp plus quattro tiptronic', '4000', 'Benzin', 'Otomatik', 1499890, 'http://www.audi.com.tr/'),
(131, 'Audi', 'TT Coupe', '2.0 TFSI 230 hp quattro S tronic', '2000', 'Benzin', 'Otomatik', 396851, 'http://www.audi.com.tr/'),
(132, 'Audi', 'TTS Coupe', '2.0 TFSI 310 hp quattro S tronic', '2000', 'Benzin', 'Otomatik', 445001, 'http://www.audi.com.tr/'),
(133, 'Bmw', '116d', '1.5 116BG Joy', '1500', 'Dizel', 'Otomatik', 166100, 'http://www.bmw.com.tr/'),
(134, 'Bmw', '116d', '1.5 116BG Joy Plus', '1500', 'Dizel', 'Otomatik', 169700, 'http://www.bmw.com.tr/'),
(135, 'Bmw', '116d', '1.5 116BG M Plus', '1500', 'Dizel', 'Otomatik', 180400, 'http://www.bmw.com.tr/'),
(136, 'Bmw', '116d', '1.5 116BG Pure', '1500', 'Dizel', 'Otomatik', 155300, 'http://www.bmw.com.tr/'),
(137, 'Bmw', '118i', '1.5 136BG Joy', '1500', 'Benzin', 'Otomatik', 155300, 'http://www.bmw.com.tr/'),
(138, 'Bmw', '118i', '1.5 136BG Joy Plus', '1500', 'Benzin', 'Otomatik', 158900, 'http://www.bmw.com.tr/'),
(139, 'Bmw', '118i', '1.5 136BG M Plus', '1500', 'Benzin', 'Otomatik', 169700, 'http://www.bmw.com.tr/'),
(140, 'Bmw', '118i', '1.5 136BG Pure', '1500', 'Benzin', 'Otomatik', 144600, 'http://www.bmw.com.tr/'),
(141, 'Bmw', '216d Active Tourer', '1.5 116BG Joy', '1500', 'Dizel', 'Otomatik', 175100, 'http://www.bmw.com.tr/'),
(142, 'Bmw', '216d Active Tourer', '1.5 116BG Luxury Line', '1500', 'Dizel', 'Otomatik', 190800, 'http://www.bmw.com.tr/'),
(143, 'Bmw', '216d Active Tourer', '1.5 116BG M Sport', '1500', 'Dizel', 'Otomatik', 195900, 'http://www.bmw.com.tr/'),
(144, 'Bmw', '216d Active Tourer', '1.5 116BG Prestige', '1500', 'Dizel', 'Otomatik', 184000, 'http://www.bmw.com.tr/'),
(145, 'Bmw', '216d Active Tourer', '1.5 116BG Sport Line', '1500', 'Dizel', 'Otomatik', 184700, 'http://www.bmw.com.tr/'),
(146, 'Bmw', '216d Gran Tourer', '1.5 116BG Joy', '1500', 'Dizel', 'Otomatik', 187600, 'http://www.bmw.com.tr/'),
(147, 'Bmw', '216d Gran Tourer', '1.5 116BG Luxury Line', '1500', 'Dizel', 'Otomatik', 203400, 'http://www.bmw.com.tr/'),
(148, 'Bmw', '216d Gran Tourer', '1.5 116BG M Sport', '1500', 'Dizel', 'Otomatik', 208400, 'http://www.bmw.com.tr/'),
(149, 'Bmw', '216d Gran Tourer', '1.5 116BG Prestige', '1500', 'Dizel', 'Otomatik', 196600, 'http://www.bmw.com.tr/'),
(150, 'Bmw', '216d Gran Tourer', '1.5 116BG Sport Line', '1500', 'Dizel', 'Otomatik', 197300, 'http://www.bmw.com.tr/'),
(151, 'Bmw', '218i Cabrio', '1.5 136BG Joy', '1500', 'Benzin', 'Otomatik', 202000, 'http://www.bmw.com.tr/'),
(152, 'Bmw', '218i Cabrio', '1.5 136BG Luxury Line', '1500', 'Benzin', 'Otomatik', 217700, 'http://www.bmw.com.tr/'),
(153, 'Bmw', '218i Cabrio', '1.5 136BG M Sport', '1500', 'Benzin', 'Otomatik', 221300, 'http://www.bmw.com.tr/'),
(154, 'Bmw', '218i Cabrio', '1.5 136BG Prestige', '1500', 'Benzin', 'Otomatik', 208400, 'http://www.bmw.com.tr/'),
(155, 'Bmw', '218i Cabrio', '1.5 136BG Sport Line', '1500', 'Benzin', 'Otomatik', 211300, 'http://www.bmw.com.tr/'),
(156, 'Bmw', '218i Coupe', '1.5 136BG Joy', '1500', 'Benzin', 'Otomatik', 166100, 'http://www.bmw.com.tr/'),
(157, 'Bmw', '218i Coupe', '1.5 136BG Luxury Line', '1500', 'Benzin', 'Otomatik', 181900, 'http://www.bmw.com.tr/'),
(158, 'Bmw', '218i Coupe', '1.5 136BG M Sport', '1500', 'Benzin', 'Otomatik', 185500, 'http://www.bmw.com.tr/'),
(159, 'Bmw', '218i Coupe', '1.5 136BG Prestige', '1500', 'Benzin', 'Otomatik', 173300, 'http://www.bmw.com.tr/'),
(160, 'Bmw', '218i Coupe', '1.5 136BG Sport Line', '1500', 'Benzin', 'Otomatik', 175400, 'http://www.bmw.com.tr/'),
(161, 'Bmw', '318d Sedan', '2.0 150BG 40th Year Edition', '2000', 'Dizel', 'Otomatik', 299800, 'http://www.bmw.com.tr/'),
(162, 'Bmw', '318d Sedan', '2.0 150BG Joy', '2000', 'Dizel', 'Otomatik', 214100, 'http://www.bmw.com.tr/'),
(163, 'Bmw', '318d Sedan', '2.0 150BG Luxury Plus', '2000', 'Dizel', 'Otomatik', 272500, 'http://www.bmw.com.tr/'),
(164, 'Bmw', '318d Sedan', '2.0 150BG M Plus', '2000', 'Dizel', 'Otomatik', 262000, 'http://www.bmw.com.tr/'),
(165, 'Bmw', '318d Sedan', '2.0 150BG Prestige', '2000', 'Dizel', 'Otomatik', 234900, 'http://www.bmw.com.tr/'),
(166, 'Bmw', '318d Sedan', '2.0 150BG Sport Plus', '2000', 'Dizel', 'Otomatik', 250700, 'http://www.bmw.com.tr/'),
(167, 'Bmw', '318i Sedan', '1.5 136BG 40th Year Edition', '1500', 'Benzin', 'Otomatik', 246800, 'http://www.bmw.com.tr/'),
(168, 'Bmw', '318i Sedan', '1.5 136BG Joy', '1500', 'Benzin', 'Otomatik', 187600, 'http://www.bmw.com.tr/'),
(169, 'Bmw', '318i Sedan', '1.5 136BG Luxury Plus', '1500', 'Benzin', 'Otomatik', 225300, 'http://www.bmw.com.tr/'),
(170, 'Bmw', '318i Sedan', '1.5 136BG M Plus', '1500', 'Benzin', 'Otomatik', 217000, 'http://www.bmw.com.tr/'),
(171, 'Bmw', '318i Sedan', '1.5 136BG Prestige', '1500', 'Benzin', 'Otomatik', 204800, 'http://www.bmw.com.tr/'),
(172, 'Bmw', '318i Sedan', '1.5 136BG Sport Plus', '1500', 'Benzin', 'Otomatik', 208100, 'http://www.bmw.com.tr/'),
(173, 'Bmw', '320d Sedan', '2.0 190BG 40th Year Edition', '2000', 'Dizel', 'Otomatik', 322200, 'http://www.bmw.com.tr/'),
(174, 'Bmw', '320d Sedan', '2.0 190BG Joy', '2000', 'Dizel', 'Otomatik', 232900, 'http://www.bmw.com.tr/'),
(175, 'Bmw', '320d Sedan', '2.0 190BG Luxury Plus', '2000', 'Dizel', 'Otomatik', 293900, 'http://www.bmw.com.tr/'),
(176, 'Bmw', '320d Sedan', '2.0 190BG M Plus', '2000', 'Dizel', 'Otomatik', 283100, 'http://www.bmw.com.tr/'),
(177, 'Bmw', '320d Sedan', '2.0 190BG Prestige', '2000', 'Dizel', 'Otomatik', 267100, 'http://www.bmw.com.tr/'),
(178, 'Bmw', '320d Sedan', '2.0 190BG Sport Plus', '2000', 'Dizel', 'Otomatik', 271300, 'http://www.bmw.com.tr/'),
(179, 'Bmw', '320d Gran Turismo', '2.0 190BG 40th Year Edition xDrive', '2000', 'Dizel', 'Otomatik', 425700, 'http://www.bmw.com.tr/'),
(180, 'Bmw', '320d Gran Turismo', '2.0 190BG Joy xDrive', '2000', 'Dizel', 'Otomatik', 312700, 'http://www.bmw.com.tr/'),
(181, 'Bmw', '320d Gran Turismo', '2.0 190BG Luxury Plus xDrive', '2000', 'Dizel', 'Otomatik', 376800, 'http://www.bmw.com.tr/'),
(182, 'Bmw', '320d Gran Turismo', '2.0 190BG M Plus xDrive', '2000', 'Dizel', 'Otomatik', 374900, 'http://www.bmw.com.tr/'),
(183, 'Bmw', '320d Gran Turismo', '2.0 190BG Prestige xDrive', '2000', 'Dizel', 'Otomatik', 343800, 'http://www.bmw.com.tr/'),
(184, 'Bmw', '320d Gran Turismo', '2.0 190BG Sport Plus Xdrive', '2000', 'Dizel', 'Otomatik', 357900, 'http://www.bmw.com.tr/'),
(185, 'Bmw', '320d Sedan', '2.0 190BG 40th Year Edition', '2000', 'Dizel', 'Otomatik', 340500, 'http://www.bmw.com.tr/'),
(186, 'Bmw', '320d Sedan', '2.0 190BG Joy xDrive', '2000', 'Dizel', 'Otomatik', 262800, 'http://www.bmw.com.tr/'),
(187, 'Bmw', '320d Sedan', '2.0 190BG Luxury Plus xDrive', '2000', 'Dizel', 'Otomatik', 312300, 'http://www.bmw.com.tr/'),
(188, 'Bmw', '320d Sedan', '2.0 190BG M Plus xDrive', '2000', 'Dizel', 'Otomatik', 301400, 'http://www.bmw.com.tr/'),
(189, 'Bmw', '320d Sedan', '2.0 190BG Prestige xDrive', '2000', 'Dizel', 'Otomatik', 285400, 'http://www.bmw.com.tr/'),
(190, 'Bmw', '320d Sedan', '2.0 190BG Sport Plus xDrive', '2000', 'Dizel', 'Otomatik', 289700, 'http://www.bmw.com.tr/'),
(191, 'Bmw', '418d Coupe', '2.0 150BG Joy', '2000', 'Dizel', 'Otomatik', 283600, 'http://www.bmw.com.tr/'),
(192, 'Bmw', '418d Coupe', '2.0 150BG Luxury Plus', '2000', 'Dizel', 'Otomatik', 322200, 'http://www.bmw.com.tr/'),
(193, 'Bmw', '418d Coupe', '2.0 150BG M Plus', '2000', 'Dizel', 'Otomatik', 313700, 'http://www.bmw.com.tr/'),
(194, 'Bmw', '418d Coupe', '2.0 150BG Prestige', '2000', 'Dizel', 'Otomatik', 294900, 'http://www.bmw.com.tr/'),
(195, 'Bmw', '418d Coupe', '2.0 150BG Sport Plus', '2000', 'Dizel', 'Otomatik', 309000, 'http://www.bmw.com.tr/'),
(196, 'Bmw', '418d Coupe', '2.0 150BG Ultimate M Sport', '2000', 'Dizel', 'Otomatik', 349500, 'http://www.bmw.com.tr/'),
(197, 'Bmw', '418d Gran Coupe', '2.0 190BG Joy', '2000', 'Dizel', 'Otomatik', 286400, 'http://www.bmw.com.tr/'),
(198, 'Bmw', '418d Gran Coupe', '2.0 190BG Luxury Plus', '2000', 'Dizel', 'Otomatik', 325000, 'http://www.bmw.com.tr/'),
(199, 'Bmw', '418d Gran Coupe', '2.0 190BG M Plus', '2000', 'Dizel', 'Otomatik', 316500, 'http://www.bmw.com.tr/'),
(200, 'Bmw', '418d Gran Coupe', '2.0 190BG Prestige', '2000', 'Dizel', 'Otomatik', 297700, 'http://www.bmw.com.tr/'),
(201, 'Bmw', '418d Gran Coupe', '2.0 190BG Sport Plus', '2000', 'Dizel', 'Otomatik', 311800, 'http://www.bmw.com.tr/'),
(202, 'Bmw', '418d Gran Coupe', '2.0 190BG Ultimate M Sport', '2000', 'Dizel', 'Otomatik', 352300, 'http://www.bmw.com.tr/'),
(203, 'Bmw', '418i Coupe', '1.5 136BG Joy', '1500', 'Benzin', 'Otomatik', 215600, 'http://www.bmw.com.tr/'),
(204, 'Bmw', '418i Coupe', '1.5 136BG Luxury Plus', '1500', 'Benzin', 'Otomatik', 245000, 'http://www.bmw.com.tr/'),
(205, 'Bmw', '418i Coupe', '1.5 136BG M Plus', '1500', 'Benzin', 'Otomatik', 238600, 'http://www.bmw.com.tr/'),
(206, 'Bmw', '418i Coupe', '1.5 136BG Prestige', '1500', 'Benzin', 'Otomatik', 224200, 'http://www.bmw.com.tr/'),
(207, 'Bmw', '418i Coupe', '1.5 136BG Sport Plus', '1500', 'Benzin', 'Otomatik', 235000, 'http://www.bmw.com.tr/'),
(208, 'Bmw', '418i Coupe', '1.5 136BG Ultimate M Sport', '1500', 'Benzin', 'Otomatik', 265800, 'http://www.bmw.com.tr/'),
(209, 'Bmw', '418i Gran Coupe', '1.5 136BG Joy', '1500', 'Benzin', 'Otomatik', 217700, 'http://www.bmw.com.tr/'),
(210, 'Bmw', '418i Gran Coupe', '1.5 136BG Luxury Plus', '1500', 'Benzin', 'Otomatik', 247200, 'http://www.bmw.com.tr/'),
(211, 'Bmw', '418i Gran Coupe', '1.5 136BG M Plus', '1500', 'Benzin', 'Otomatik', 240700, 'http://www.bmw.com.tr/'),
(212, 'Bmw', '418i Gran Coupe', '1.5 136BG Prestige', '1500', 'Benzin', 'Otomatik', 226400, 'http://www.bmw.com.tr/'),
(213, 'Bmw', '418i Gran Coupe', '1.5 136BG Sport Plus', '1500', 'Benzin', 'Otomatik', 237100, 'http://www.bmw.com.tr/'),
(214, 'Bmw', '418i Gran Coupe', '1.5 136BG Ultimate M Sport', '1500', 'Benzin', 'Otomatik', 268000, 'http://www.bmw.com.tr/'),
(215, 'Bmw', '420d Cabrio', '2.0 190BG Luxury Line', '2000', 'Dizel', 'Otomatik', 404100, 'http://www.bmw.com.tr/'),
(216, 'Bmw', '420d Cabrio', '2.0 190BG M PLus', '2000', 'Dizel', 'Otomatik', 415400, 'http://www.bmw.com.tr/'),
(217, 'Bmw', '420d Cabrio', '2.0 190BG Sport Line', '2000', 'Dizel', 'Otomatik', 400300, 'http://www.bmw.com.tr/'),
(218, 'Bmw', '420d Cabrio', '2.0 190BG Ultimate M Sport', '2000', 'Dizel', 'Otomatik', 449300, 'http://www.bmw.com.tr/'),
(219, 'Bmw', '420d Coupe', '2.0 190BG Joy xDrive', '2000', 'Dizel', 'Otomatik', 322200, 'http://www.bmw.com.tr/'),
(220, 'Bmw', '420d Coupe', '2.0 190BG Luxury Plus xDrive', '2000', 'Dizel', 'Otomatik', 360800, 'http://www.bmw.com.tr/'),
(221, 'Bmw', '420d Coupe', '2.0 190BG M Plus xDrive', '2000', 'Dizel', 'Otomatik', 352300, 'http://www.bmw.com.tr/'),
(222, 'Bmw', '420d Coupe', '2.0 190BG Sport Plus xDrive', '2000', 'Dizel', 'Otomatik', 347600, 'http://www.bmw.com.tr/'),
(223, 'Bmw', '420d Coupe', '2.0 190BG Ultimate M Sport xDrive', '2000', 'Dizel', 'Otomatik', 388100, 'http://www.bmw.com.tr/'),
(224, 'Bmw', '420d Gran Coupe', '2.0 190BG Joy xDrive', '2000', 'Dizel', 'Otomatik', 325000, 'http://www.bmw.com.tr/'),
(225, 'Bmw', '420d Gran Coupe', '2.0 190BG Luxury Plus xDrive', '2000', 'Dizel', 'Otomatik', 363600, 'http://www.bmw.com.tr/'),
(226, 'Bmw', '420d Gran Coupe', '2.0 190BG M Plus xDrive', '2000', 'Dizel', 'Otomatik', 355100, 'http://www.bmw.com.tr/'),
(227, 'Bmw', '420d Gran Coupe', '2.0 190BG Sport Plus xDrive', '2000', 'Dizel', 'Otomatik', 350400, 'http://www.bmw.com.tr/'),
(228, 'Bmw', '420d Gran Coupe', '2.0 190BG Ultimate M Sport xDrive', '2000', 'Dizel', 'Otomatik', 390900, 'http://www.bmw.com.tr/'),
(229, 'Bmw', '430i Cabrio', '2.0 252BG Luxury Line xDrive', '2000', 'Benzin', 'Otomatik', 437000, 'http://www.bmw.com.tr/'),
(230, 'Bmw', '430i Cabrio', '2.0 252BG M Sport xDrive', '2000', 'Benzin', 'Otomatik', 448300, 'http://www.bmw.com.tr/'),
(231, 'Bmw', '430i Cabrio', '2.0 252BG Sport Line xDrive', '2000', 'Benzin', 'Otomatik', 433300, 'http://www.bmw.com.tr/'),
(232, 'Bmw', '430i Cabrio', '2.0 252BG Ulitmate M Sport xDrive', '2000', 'Benzin', 'Otomatik', 482200, 'http://www.bmw.com.tr/'),
(233, 'Bmw', '430i Coupe', '2.0 252BG Joy xDrive', '2000', 'Benzin', 'Otomatik', 359800, 'http://www.bmw.com.tr/'),
(234, 'Bmw', '430i Coupe', '2.0 252BG Luxury Plus xDrive', '2000', 'Benzin', 'Otomatik', 398400, 'http://www.bmw.com.tr/'),
(235, 'Bmw', '430i Coupe', '2.0 252BG M Plus xDrive', '2000', 'Benzin', 'Otomatik', 390000, 'http://www.bmw.com.tr/'),
(236, 'Bmw', '430i Coupe', '2.0 252BG Sport Plus xDrive', '2000', 'Benzin', 'Otomatik', 385300, 'http://www.bmw.com.tr/'),
(237, 'Bmw', '430i Coupe', '2.0 252BG Ultimate M Sport xDrive', '2000', 'Benzin', 'Otomatik', 425700, 'http://www.bmw.com.tr/'),
(238, 'Bmw', '430i Gran Coupe', '2.0 252BG Joy xDrive', '2000', 'Benzin', 'Otomatik', 362700, 'http://www.bmw.com.tr/'),
(239, 'Bmw', '430i Gran Coupe', '2.0 252BG Luxury Plus xDrive', '2000', 'Benzin', 'Otomatik', 401300, 'http://www.bmw.com.tr/'),
(240, 'Bmw', '430i Gran Coupe', '2.0 252BG M Plus xDrive', '2000', 'Benzin', 'Otomatik', 392800, 'http://www.bmw.com.tr/'),
(241, 'Bmw', '430i Gran Coupe', '2.0 252BG Sport Plus xDrive', '2000', 'Benzin', 'Otomatik', 388100, 'http://www.bmw.com.tr/'),
(242, 'Bmw', '430i Gran Coupe', '2.0 252BG Ultimate M Sport xDrive', '2000', 'Benzin', 'Otomatik', 428600, 'http://www.bmw.com.tr/'),
(243, 'Bmw', '520d Sedan', '2.0 190BG Luxury Line', '2000', 'Dizel', 'Otomatik', 416300, 'http://www.bmw.com.tr/'),
(244, 'Bmw', '520d Sedan', '2.0 190BG M Sport', '2000', 'Dizel', 'Otomatik', 423400, 'http://www.bmw.com.tr/'),
(245, 'Bmw', '520d Sedan', '2.0 190BG Prestige', '2000', 'Dizel', 'Otomatik', 406900, 'http://www.bmw.com.tr/'),
(246, 'Bmw', '520d Sedan', '2.0 190BG Sport Line', '2000', 'Dizel', 'Otomatik', 404600, 'http://www.bmw.com.tr/'),
(247, 'Bmw', '520d Sedan', '2.0 190BG Luxury Line xDrive', '2000', 'Dizel', 'Otomatik', 437500, 'http://www.bmw.com.tr/'),
(248, 'Bmw', '520d Sedan', '2.0 190BG M Sport xDrive', '2000', 'Dizel', 'Otomatik', 444600, 'http://www.bmw.com.tr/'),
(249, 'Bmw', '520d Sedan', '2.0 190BG Prestige xDrive', '2000', 'Dizel', 'Otomatik', 428100, 'http://www.bmw.com.tr/'),
(250, 'Bmw', '520d Sedan', '2.0 190BG Sport Line xDrive', '2000', 'Dizel', 'Otomatik', 425700, 'http://www.bmw.com.tr/'),
(251, 'Bmw', '520d Sedan', '3.0 265BG Luxury Line xDrive', '3000', 'Dizel', 'Otomatik', 595200, 'http://www.bmw.com.tr/'),
(252, 'Bmw', '520d Sedan', '3.0 265BG M Sport xDrive', '3000', 'Dizel', 'Otomatik', 604000, 'http://www.bmw.com.tr/'),
(253, 'Bmw', '520d Sedan', '3.0 265BG Prestige xDrive', '3000', 'Dizel', 'Otomatik', 583600, 'http://www.bmw.com.tr/'),
(254, 'Bmw', '520d Sedan', '3.0 265BG Sport Line xDrive', '3000', 'Dizel', 'Otomatik', 580700, 'http://www.bmw.com.tr/'),
(255, 'Bmw', '530i Sedan', '2.0 252BG Executive Luxury', '2000', 'Benzin', 'Otomatik', 338600, 'http://www.bmw.com.tr/'),
(256, 'Bmw', '530i Sedan', '2.0 252BG Executive M', '2000', 'Benzin', 'Otomatik', 343300, 'http://www.bmw.com.tr/'),
(257, 'Bmw', '530i Sedan', '2.0 252BG Executive Prestige', '2000', 'Benzin', 'Otomatik', 329200, 'http://www.bmw.com.tr/'),
(258, 'Bmw', '530i Sedan', '2.0 252BG Executive Sport', '2000', 'Benzin', 'Otomatik', 326900, 'http://www.bmw.com.tr/'),
(259, 'Bmw', '530i Sedan', '2.0 252BG Executive Luxury xDrive', '2000', 'Benzin', 'Otomatik', 360300, 'http://www.bmw.com.tr/'),
(260, 'Bmw', '530i Sedan', '2.0 252BG Executive M xDrive', '2000', 'Benzin', 'Otomatik', 365000, 'http://www.bmw.com.tr/'),
(261, 'Bmw', '530i Sedan', '2.0 252BG Executive Prestige xDrive', '2000', 'Benzin', 'Otomatik', 350900, 'http://www.bmw.com.tr/'),
(262, 'Bmw', '530i Sedan', '2.0 252BG Executive Sport xDrive', '2000', 'Benzin', 'Otomatik', 348500, 'http://www.bmw.com.tr/'),
(263, 'Bmw', '540i Sedan', '3.0 340BG Executive Luxury xDrive', '3000', 'Benzin', 'Otomatik', 595200, 'http://www.bmw.com.tr/'),
(264, 'Bmw', '540i Sedan', '3.0 340BG Executive M xDrive', '3000', 'Benzin', 'Otomatik', 601100, 'http://www.bmw.com.tr/'),
(265, 'Bmw', '540i Sedan', '3.0 340BG Executive Prestige xDrive', '3000', 'Benzin', 'Otomatik', 583600, 'http://www.bmw.com.tr/'),
(266, 'Bmw', '540i Sedan', '3.0 340BG Executive Sport xDrive', '3000', 'Benzin', 'Otomatik', 580700, 'http://www.bmw.com.tr/'),
(267, 'Bmw', '640d Cabrio', '3.0 313BG M Sport xDrive', '3000', 'Dizel', 'Otomatik', 942100, 'http://www.bmw.com.tr/'),
(268, 'Bmw', '640d Cabrio', '3.0 313BG Pure xDrive', '3000', 'Dizel', 'Otomatik', 866300, 'http://www.bmw.com.tr/'),
(269, 'Bmw', '640d Cabrio', '3.0 313BG Pure Excellence xDrive', '3000', 'Dizel', 'Otomatik', 895400, 'http://www.bmw.com.tr/'),
(270, 'Bmw', '640d Cabrio', '3.0 313BG Pure Experience xDrive', '3000', 'Dizel', 'Otomatik', 907100, 'http://www.bmw.com.tr/'),
(271, 'Bmw', '640d Coupe', '3.0 313BG M Sport xDrive', '3000', 'Dizel', 'Otomatik', 872100, 'http://www.bmw.com.tr/'),
(272, 'Bmw', '640d Coupe', '3.0 313BG Pure xDrive', '3000', 'Dizel', 'Otomatik', 796300, 'http://www.bmw.com.tr/'),
(273, 'Bmw', '640d Coupe', '3.0 313BG Pure Excellence xDrive', '3000', 'Dizel', 'Otomatik', 825500, 'http://www.bmw.com.tr/'),
(274, 'Bmw', '640d Coupe', '3.0 313BG Pure Experience xDrive', '3000', 'Dizel', 'Otomatik', 837100, 'http://www.bmw.com.tr/'),
(275, 'Bmw', '640d Gran Coupe', '3.0 313BG M Sport xDrive', '3000', 'Dizel', 'Otomatik', 895400, 'http://www.bmw.com.tr/'),
(276, 'Bmw', '640d Gran Coupe', '3.0 313BG Pure xDrive', '3000', 'Dizel', 'Otomatik', 819700, 'http://www.bmw.com.tr/'),
(277, 'Bmw', '640d Gran Coupe', '3.0 313BG Pure Excellence xDrive', '3000', 'Dizel', 'Otomatik', 848800, 'http://www.bmw.com.tr/'),
(278, 'Bmw', '640d Gran Coupe', '3.0 313BG Pure Experience xDrive', '3000', 'Dizel', 'Otomatik', 860500, 'http://www.bmw.com.tr/'),
(279, 'Bmw', '725d', '2.0 231BG M Excellence', '2000', 'Dizel', 'Otomatik', 887100, 'http://www.bmw.com.tr/'),
(280, 'Bmw', '725d', '2.0 231BG M Sport', '2000', 'Dizel', 'Otomatik', 882400, 'http://www.bmw.com.tr/'),
(281, 'Bmw', '725d', '2.0 231BG Pure Excellence', '2000', 'Dizel', 'Otomatik', 875400, 'http://www.bmw.com.tr/'),
(282, 'Bmw', '725Ld', '2.0 231BG M Excellence', '2000', 'Dizel', 'Otomatik', 929500, 'http://www.bmw.com.tr/'),
(283, 'Bmw', '725Ld', '2.0 231BG M Sport', '2000', 'Dizel', 'Otomatik', 914000, 'http://www.bmw.com.tr/'),
(284, 'Bmw', '725Ld', '2.0 231BG Pure Excellence', '2000', 'Dizel', 'Otomatik', 917700, 'http://www.bmw.com.tr/'),
(285, 'Bmw', '730d', '3.0 265BG M Excellence xDrive', '3000', 'Dizel', 'Otomatik', 1122800, 'http://www.bmw.com.tr/'),
(286, 'Bmw', '730d', '3.0 265BG M Sport xDrive', '3000', 'Dizel', 'Otomatik', 1117000, 'http://www.bmw.com.tr/'),
(287, 'Bmw', '730d', '3.0 265BG Pure Excellence xDrive', '3000', 'Dizel', 'Otomatik', 1108200, 'http://www.bmw.com.tr/'),
(288, 'Bmw', '730i', '2.0 258BG M Excellence', '2000', 'Benzin', 'Otomatik', 868300, 'http://www.bmw.com.tr/'),
(289, 'Bmw', '730i', '2.0 258BG M Sport', '2000', 'Benzin', 'Otomatik', 863600, 'http://www.bmw.com.tr/'),
(290, 'Bmw', '730i', '2.0 258BG Pure Excellence', '2000', 'Benzin', 'Otomatik', 856500, 'http://www.bmw.com.tr/'),
(291, 'Bmw', '730Ld', '3.0 265BG M Excellence xDrive', '3000', 'Dizel', 'Otomatik', 1198600, 'http://www.bmw.com.tr/'),
(292, 'Bmw', '730Ld', '3.0 265BG M Sport xDrive', '3000', 'Dizel', 'Otomatik', 1179300, 'http://www.bmw.com.tr/'),
(293, 'Bmw', '730Ld', '3.0 265BG Pure Excellence xDrive', '3000', 'Dizel', 'Otomatik', 1184000, 'http://www.bmw.com.tr/'),
(294, 'Bmw', '730Li', '2.0 258BG M Excellence', '2000', 'Benzin', 'Otomatik', 910700, 'http://www.bmw.com.tr/'),
(295, 'Bmw', '730Li', '2.0 258BG M Sport', '2000', 'Benzin', 'Otomatik', 895100, 'http://www.bmw.com.tr/'),
(296, 'Bmw', '730Li', '2.0 258BG Pure Excellence', '2000', 'Benzin', 'Otomatik', 898900, 'http://www.bmw.com.tr/'),
(297, 'Bmw', '740Le', '2.0 326 3BG M Excellence xDrive iPerformance', '2000', 'Hibrit', 'Otomatik', 1004900, 'http://www.bmw.com.tr/'),
(298, 'Bmw', '740Le', '2.0 326 3BG M Sport xDrive iPerformance', '2000', 'Hibrit', 'Otomatik', 989300, 'http://www.bmw.com.tr/'),
(299, 'Bmw', '740Le', '2.0 326 3BG Pure Excellence xDrive iPerformance', '2000', 'Hibrit', 'Otomatik', 993100, 'http://www.bmw.com.tr/'),
(300, 'Bmw', '750Ld', '3.0 400BG M Excellence xDrive', '3000', 'Dizel', 'Otomatik', 1414200, 'http://www.bmw.com.tr/');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user`
--

CREATE TABLE `user` (
  `email` varchar(254) NOT NULL,
  `password` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `user`
--

INSERT INTO `user` (`email`, `password`) VALUES
('admin', '12345');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `otomobil_fiyatlari`
--
ALTER TABLE `otomobil_fiyatlari`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `otomobil_fiyatlari`
--
ALTER TABLE `otomobil_fiyatlari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1667;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
