package com.example.java_restapi_teamcreation_springbootrestapimysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaRestApiTeamCreationSpringBootRestApiMySqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavaRestApiTeamCreationSpringBootRestApiMySqlApplication.class, args);
    }

}
