package com.example.java_restapi_teamcreation_springbootrestapimysql.configs;

import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Footballer;
import org.springframework.context.annotation.Configuration;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@Configuration
public class FilterConfig implements Filter {


    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        String[] freeUrls = {"/footballer/footballerRegister", "/footballer/login"};; //Bizim free alan olarak göstermek istediğimiz URL
        String url = request.getRequestURI(); //kullanıcının gitmek istediği URL

        boolean loginStatus = true;

        for (String item : freeUrls) {
            if (url.equals(item)) {
                loginStatus = false;

            }
        }

        if (loginStatus) {
            boolean status = request.getSession().getAttribute("footballer") == null; //Admin Servicedeki login metodunda bu userı kurduk oraya gidiyor.
            if (status) {
                //User yok burada demek oluyor.
                PrintWriter printWriter = response.getWriter();
                printWriter.println("{\n" +
                        "  \"status\": false,\n" +
                        "  \"result\": \"please login\"\n" +
                        "}");
                response.setContentType("application/json");
                response.setStatus(401);
            }else {
                //Session True
                filterChain.doFilter(request,response);
            }
        }else {
            filterChain.doFilter(request,response);
        }



    }
}
