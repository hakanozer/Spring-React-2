package com.example.java_restapi_teamcreation_springbootrestapimysql.configs;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolationException;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalException {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity methodArgumentNotValid(MethodArgumentNotValidException exception){
        Map<String, Object> hm = new LinkedHashMap<>();
        hm.put("status", false);
        hm.put("result", exception.getFieldErrors());
        return new ResponseEntity(hm, HttpStatus.BAD_REQUEST);
    }





}
