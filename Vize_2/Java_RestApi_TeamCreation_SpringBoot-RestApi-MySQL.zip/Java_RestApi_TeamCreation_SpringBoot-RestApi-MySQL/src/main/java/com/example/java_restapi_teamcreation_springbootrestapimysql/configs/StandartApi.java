package com.example.java_restapi_teamcreation_springbootrestapimysql.configs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
public class StandartApi {

    private boolean status;

    private Object result;
}
