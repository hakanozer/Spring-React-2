package com.example.java_restapi_teamcreation_springbootrestapimysql.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.validation.constraints.*;
import java.util.List;

@Entity
@Data
public class Footballer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer fid;


    @NotEmpty
    @NotNull
    private String name;


    @NotEmpty
    @NotNull
    private String surname;

    @Column(unique = true)
    @NotEmpty
    @NotNull
    @Email
    private String email;


    @NotEmpty
    @NotNull
    private String password;

    @Min(message = "Under 18 years old footballers cannot register" , value = 18)
    @NotNull()
    private Integer age;












}
