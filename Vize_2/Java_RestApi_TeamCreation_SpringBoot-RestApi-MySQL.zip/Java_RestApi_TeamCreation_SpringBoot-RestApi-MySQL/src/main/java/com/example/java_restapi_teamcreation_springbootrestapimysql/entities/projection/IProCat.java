package com.example.java_restapi_teamcreation_springbootrestapimysql.entities.projection;

public interface IProCat {

}
