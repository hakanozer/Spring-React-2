package com.example.java_restapi_teamcreation_springbootrestapimysql.repositories;

import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.ConcatTeams;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConcatTeamsRepository extends JpaRepository<ConcatTeams, Integer> {
}