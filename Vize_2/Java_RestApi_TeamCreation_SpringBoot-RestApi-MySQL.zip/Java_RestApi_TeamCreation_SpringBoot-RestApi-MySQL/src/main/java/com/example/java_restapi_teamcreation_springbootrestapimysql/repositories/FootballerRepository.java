package com.example.java_restapi_teamcreation_springbootrestapimysql.repositories;

import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Footballer;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Team;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.Optional;

public interface FootballerRepository extends JpaRepository<Footballer, Integer> {


    Optional<Footballer> findByEmailAndPasswordIgnoreCase(String email, String password);







}