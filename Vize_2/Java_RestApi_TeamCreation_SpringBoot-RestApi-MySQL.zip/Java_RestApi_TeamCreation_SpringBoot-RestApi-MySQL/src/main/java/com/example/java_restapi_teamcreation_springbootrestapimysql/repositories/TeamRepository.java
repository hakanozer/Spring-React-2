package com.example.java_restapi_teamcreation_springbootrestapimysql.repositories;

import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team, Integer> {







}