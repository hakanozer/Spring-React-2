package com.example.java_restapi_teamcreation_springbootrestapimysql.restcontrollers;

import com.example.java_restapi_teamcreation_springbootrestapimysql.configs.GlobalException;
import com.example.java_restapi_teamcreation_springbootrestapimysql.configs.StandartApi;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Footballer;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Team;
import com.example.java_restapi_teamcreation_springbootrestapimysql.services.FootballerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
@RequestMapping("/footballer")
public class FootballerRestController {

    final FootballerService footballerService;
    final HttpServletRequest request;


    @PostMapping("/footballerRegister")
    public ResponseEntity register(@Valid @RequestBody Footballer footballer)  {

        return footballerService.footballerRegister(footballer);
    }

    @PostMapping("/login")
    public ResponseEntity login(@RequestBody Footballer footballer){
        Footballer fs = footballerService.login(footballer);
        if (fs != null) {
            request.getSession().setAttribute("footballer", fs.getFid());
            StandartApi standartApi = new StandartApi(true,fs);
            return new ResponseEntity<>(standartApi, HttpStatus.OK);
        }else {
            StandartApi standartApi = new StandartApi(false,"Try Again");
            return new ResponseEntity<>(standartApi,HttpStatus.BAD_REQUEST) ;
        }


    }





}
