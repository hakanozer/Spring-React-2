package com.example.java_restapi_teamcreation_springbootrestapimysql.restcontrollers;

import com.example.java_restapi_teamcreation_springbootrestapimysql.services.TeamService;
import lombok.RequiredArgsConstructor;
import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/teams")
public class TeamsRestController {
    final TeamService teamService;

    @PostMapping("/teamInsert/{tid}")
    public ResponseEntity insertTeam(@PathVariable Integer tid){

        return teamService.teamInsert(tid);
    }


}
