package com.example.java_restapi_teamcreation_springbootrestapimysql.services;

import com.example.java_restapi_teamcreation_springbootrestapimysql.configs.GlobalException;
import com.example.java_restapi_teamcreation_springbootrestapimysql.configs.StandartApi;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Footballer;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Team;
import com.example.java_restapi_teamcreation_springbootrestapimysql.repositories.FootballerRepository;
import com.example.java_restapi_teamcreation_springbootrestapimysql.repositories.TeamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.CriteriaBuilder;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.fasterxml.jackson.databind.type.LogicalType.Collection;

@Service
@RequiredArgsConstructor
public class FootballerService {
    final HttpServletRequest request;

    final FootballerRepository footballerRepository;
    final TeamRepository teamRepository;
    final TinkEncDec tinkEncDec;

    public ResponseEntity footballerRegister(Footballer footballer){
        String chipherText = tinkEncDec.encrypt(footballer.getPassword());
        footballer.setPassword(chipherText);
        try {
            footballerRepository.save(footballer);
            StandartApi standartApi = new StandartApi(true, footballer);
            return new ResponseEntity<>(standartApi, HttpStatus.OK);

        }catch (Exception ex){

            StandartApi standartApi = new StandartApi(false, ex.getLocalizedMessage());
            return new ResponseEntity<>(standartApi, HttpStatus.BAD_REQUEST);

        }
    }


    public Footballer login(Footballer footballer) {

        List<Footballer> footballers = footballerRepository.findAll();

        for (Footballer foots: footballers) {
            if (footballer.getEmail().equals(foots.getEmail())) {
                String plainText =tinkEncDec.decrypt(foots.getPassword());

                if (footballer.getPassword().equals(plainText)) {
                    return foots;
                }



            }
        }

        return null;
    }










}
