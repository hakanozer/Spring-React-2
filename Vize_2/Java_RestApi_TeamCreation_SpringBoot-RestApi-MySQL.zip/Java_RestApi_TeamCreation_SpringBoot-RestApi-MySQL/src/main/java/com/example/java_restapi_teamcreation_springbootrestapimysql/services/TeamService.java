package com.example.java_restapi_teamcreation_springbootrestapimysql.services;

import com.example.java_restapi_teamcreation_springbootrestapimysql.configs.StandartApi;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.Backup;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.ConcatTeams;
import com.example.java_restapi_teamcreation_springbootrestapimysql.entities.projection.IProCat;
import com.example.java_restapi_teamcreation_springbootrestapimysql.repositories.ConcatTeamsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TeamService {

    final ConcatTeamsRepository concatTeamsRepository;
    final HttpServletRequest request;

    public ResponseEntity teamInsert(Integer tid){
        ConcatTeams concatTeams = new ConcatTeams();

        List<ConcatTeams> concatTeamNumber = concatTeamsRepository.findAllById(Collections.singleton(tid));

        try {
            concatTeams.setTid(tid);
            Integer fid = (Integer) request.getSession().getAttribute("footballer");
            concatTeams.setFid(fid);
            if (concatTeamNumber.size()<= 6) {
                concatTeamsRepository.save(concatTeams);
                StandartApi standartApi = new StandartApi(true, concatTeams);
                return new ResponseEntity<>(standartApi,HttpStatus.OK);
            }
            return new ResponseEntity<>(null,HttpStatus.OK);
            }
        catch (Exception ex){
            StandartApi standartApi = new StandartApi(false,ex);
            return new ResponseEntity<>(standartApi, HttpStatus.BAD_REQUEST);
        }

    }


    }





