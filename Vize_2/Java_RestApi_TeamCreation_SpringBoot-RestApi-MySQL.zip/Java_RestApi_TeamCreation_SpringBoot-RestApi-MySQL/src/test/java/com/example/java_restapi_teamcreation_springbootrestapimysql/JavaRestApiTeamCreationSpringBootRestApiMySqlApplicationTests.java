package com.example.java_restapi_teamcreation_springbootrestapimysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaRestApiTeamCreationSpringBootRestApiMySqlApplicationTests {

    @Test
    void contextLoads() {
    }

}
