package com.works;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Vize2Application {

	public static void main(String[] args) {
		SpringApplication.run(Vize2Application.class, args);
	}

}
