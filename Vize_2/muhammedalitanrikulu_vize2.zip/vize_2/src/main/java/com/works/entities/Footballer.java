package com.works.entities;

import lombok.Data;
import org.hibernate.annotations.ColumnDefault;

import javax.persistence.*;
import javax.validation.constraints.*;


@Entity
@Data
@Table(name = "FOOTBALLER")
public class Footballer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FID")
    private Long fid;

    @Size(min = 2, max = 150)
    @NotEmpty
    @NotNull
    @Column(name = "NAME")
    private String name;

    @Size(min = 2, max = 150)
    @NotEmpty
    @NotNull
    @Column(name = "SURNAME")
    private String surname;

    @Email
    @NotEmpty
    @NotNull
    @Column(name ="EMAIL", unique = true)
    private String email;

    @Size(min = 5)
    @NotEmpty
    @NotNull
    @Column(name = "PASSWORD")
    private String password;

    @Min(18)
    @NotNull
    @Column(name = "AGE")
    private Integer age;

    @Column(name = "BACKUP")
    @ColumnDefault("false")
    private boolean backUp;
}