package com.works.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@Table(name = "FOOTBALLER_TEAMS")
public class FootballerTeam implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FTID")
    private Integer ftid;

    @Column(name = "FID")
    private Long fid;

    @Column(name = "TID")
    private Integer tid;

}