package com.works.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
@Data
@Table(name = "TEAMS")
public class Team implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TID")
    private Integer tid;
    @Column(name = "NAME")
    private String name;


    @OneToMany
    @JoinTable(name = "FOOTBALLER_TEAMS",
            joinColumns = {@JoinColumn(name = "TID",referencedColumnName = "TID")},
            inverseJoinColumns = {@JoinColumn(name = "FID",referencedColumnName = "FID")}
    )
    private Set<Footballer> footballers;

}