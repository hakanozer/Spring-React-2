package com.works.exceptions;

public class FootballerHasAlreadyInATeamException extends RuntimeException {

    public FootballerHasAlreadyInATeamException(String message){
        super(message);
    }
}
