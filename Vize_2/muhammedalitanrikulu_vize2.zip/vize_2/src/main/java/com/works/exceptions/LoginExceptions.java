package com.works.exceptions;


public class LoginExceptions extends RuntimeException {

    public LoginExceptions(String message){
        super(message);
    }
}
