package com.works.exceptions;

public class TeamCanNotFoundException extends RuntimeException {

    public TeamCanNotFoundException(String message){
        super(message);
    }
}
