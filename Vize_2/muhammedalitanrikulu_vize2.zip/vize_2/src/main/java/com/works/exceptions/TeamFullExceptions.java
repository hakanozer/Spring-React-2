package com.works.exceptions;

public class TeamFullExceptions extends RuntimeException{
    public TeamFullExceptions(String message){
        super(message);
    }
}
