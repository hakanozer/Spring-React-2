package com.works.exceptions.handler;

import com.works.configs.Rest;
import com.works.exceptions.FootballerHasAlreadyInATeamException;
import com.works.exceptions.LoginExceptions;
import com.works.exceptions.TeamCanNotFoundException;
import com.works.exceptions.TeamFullExceptions;
import javafx.fxml.LoadException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class CustomExceptionHandler {

    @ExceptionHandler(FootballerHasAlreadyInATeamException.class)
    @ResponseBody
    public ResponseEntity handleFootballerHasAlreadyInATeam(FootballerHasAlreadyInATeamException ex){
        Rest rest = new Rest(false,ex.getMessage());
        return new ResponseEntity<>(rest, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(LoginExceptions.class)
    @ResponseBody
    public ResponseEntity handleLoginException(LoginExceptions ex){
        Rest rest = new Rest(false,ex.getMessage());
        return new ResponseEntity<>(rest, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(TeamCanNotFoundException.class)
    @ResponseBody
    public ResponseEntity handleLoginException(TeamCanNotFoundException ex){
        Rest rest = new Rest(false,ex.getMessage());
        return new ResponseEntity<>(rest, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(TeamFullExceptions.class)
    @ResponseBody
    public ResponseEntity handleLoginException(TeamFullExceptions ex){
        Rest rest = new Rest(false,ex.getMessage());
        return new ResponseEntity<>(rest, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}