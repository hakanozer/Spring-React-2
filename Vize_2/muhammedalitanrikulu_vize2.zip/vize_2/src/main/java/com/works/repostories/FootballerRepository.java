package com.works.repostories;


import com.works.entities.Footballer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface FootballerRepository extends JpaRepository<Footballer, Long> {

    Optional<Footballer> findByEmailEqualsIgnoreCase(String email);

    @Query(value = "select count(*) from FOOTBALLER f inner join FOOTBALLER_TEAMS ft on f.FID = ft.FID where ft.TID = ?1 and f.BACKUP = ?2",nativeQuery = true)
    int countTeamFootballers(int teamId, boolean isBackUp);

}
