package com.works.repostories;

import com.works.entities.FootballerTeam;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FootballerTeamsRepository extends JpaRepository<FootballerTeam, Integer>{
    Optional<FootballerTeam>  findByFidEquals(Long fid);

}
