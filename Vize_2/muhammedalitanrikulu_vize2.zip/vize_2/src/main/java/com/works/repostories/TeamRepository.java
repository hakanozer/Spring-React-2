package com.works.repostories;

import com.works.entities.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team, Integer> {
    public Team findByName(String name);

}