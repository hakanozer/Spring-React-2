package com.works.restcontrollers;

import com.works.configs.Rest;
import com.works.entities.Footballer;
import com.works.services.FootballerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
@RequestMapping("/footballer")
public class FootballerRestController {

    final FootballerService footballerService;
    final HttpServletRequest req;

    @PostMapping("/register")
    public ResponseEntity register(@Valid @RequestBody Footballer footballer){
        return footballerService.register(footballer);
    }

    @PostMapping("/login")
    public ResponseEntity login(@RequestBody Footballer footballer){

        footballer = footballerService.login(footballer.getEmail(),footballer.getPassword());
        req.getSession().setAttribute("footballer",footballer);
        return new ResponseEntity<>(new Rest(true,"success"), HttpStatus.OK);
    }
    @PostMapping("/teamInsert/{teamName}")
    public ResponseEntity teamInsert(@PathVariable String teamName) {
        return footballerService.teamInsert(teamName);
    }

    @GetMapping("/teamCreate")
    public ResponseEntity teamCreate(){
        return footballerService.teamCreate();
    }

    @GetMapping("/backUpCreate")
    public ResponseEntity backUpCreate(){
        return footballerService.backUpCreate();
    }


}