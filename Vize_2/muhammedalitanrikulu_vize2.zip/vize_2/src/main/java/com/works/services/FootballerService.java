package com.works.services;

import com.works.configs.Rest;
import com.works.entities.Footballer;
import com.works.entities.FootballerTeam;
import com.works.entities.Team;
import com.works.exceptions.FootballerHasAlreadyInATeamException;
import com.works.exceptions.LoginExceptions;
import com.works.exceptions.TeamCanNotFoundException;
import com.works.exceptions.TeamFullExceptions;
import com.works.repostories.FootballerRepository;
import com.works.repostories.FootballerTeamsRepository;
import com.works.repostories.TeamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FootballerService {

    final FootballerRepository footballerRepository;
    final TinkEncDec tinkEncDec;
    final HttpServletRequest req;
    final FootballerTeamsRepository footballerTeamsRepository;
    final HttpServletResponse res;
    final TeamRepository teamRepository;

    public ResponseEntity register(Footballer footballer){
        try{
            String encryptPass = tinkEncDec.encrypt(footballer.getPassword());
            footballer.setPassword(encryptPass);
            footballerRepository.save(footballer);
            Rest rest = new Rest(true,footballer);
            return new ResponseEntity(rest, HttpStatus.OK);
        }catch (Exception ex){
            Rest rest = new Rest(false,ex.getMessage());
            return new ResponseEntity<>(rest,HttpStatus.BAD_REQUEST);
        }

    }
    public Footballer login(String email,String password){

        Optional<Footballer> optionalFootballer = footballerRepository.findByEmailEqualsIgnoreCase(email);
        String decPass = tinkEncDec.decrypt(optionalFootballer.get().getPassword());
        if(optionalFootballer.isPresent() && password.equals(decPass)){
            return optionalFootballer.get();
        }
        throw new LoginExceptions("Email or password is not true !");
    }

    public ResponseEntity teamInsert(String teamName) {

        Footballer footballer = (Footballer) req.getSession().getAttribute("footballer");
        Optional<FootballerTeam> optionalFootballerTeams = footballerTeamsRepository.findByFidEquals(footballer.getFid());
        if (optionalFootballerTeams.isPresent()) {
            throw new FootballerHasAlreadyInATeamException("Footballer has  already in a team");
        }
        Team team =teamRepository.findByName(teamName);
        if(team == null){
            throw new TeamCanNotFoundException(teamName +  " Team can not found !");
        }
        FootballerTeam footballerTeams = new FootballerTeam();
        footballerTeams.setFid(footballer.getFid());
        footballerTeams.setTid(team.getTid());
        int teamFootballerCount = footballerRepository.countTeamFootballers(team.getTid(),false);
        if(teamFootballerCount > 5){
            throw new TeamFullExceptions(teamName + " Team Full !");
        }
        int backUpFootballerCount = footballerRepository.countTeamFootballers(team.getTid(),true);
        if(backUpFootballerCount > 3){
            throw new TeamFullExceptions(teamName + " Back up Team Full !");
        }
        footballerTeamsRepository.save(footballerTeams);
        Rest rest = new Rest(true, footballerTeams);
        return new ResponseEntity(rest, HttpStatus.OK);

    }

    public ResponseEntity teamCreate(){

        try{
            List<Team> teams = teamRepository.findAll();
            return new ResponseEntity(teams,HttpStatus.OK);
        }catch (Exception ex){
            ex.printStackTrace();
            return new ResponseEntity(null,HttpStatus.BAD_REQUEST);
        }

    }
    public ResponseEntity backUpCreate(){
        try{
            List<Team> teams = teamRepository.findAll();
            return new ResponseEntity(teams,HttpStatus.OK);
        }catch (Exception ex){
            ex.printStackTrace();
            return new ResponseEntity(null,HttpStatus.BAD_REQUEST);
        }
    }


}
