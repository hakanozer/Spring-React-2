package com.works;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Vize2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
