package com.works;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UlasonurDorttasVize2Application {

    public static void main(String[] args) {
        SpringApplication.run(UlasonurDorttasVize2Application.class, args);
    }

}
