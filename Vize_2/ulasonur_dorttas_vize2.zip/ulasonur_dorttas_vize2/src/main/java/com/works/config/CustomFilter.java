package com.works.config;

import org.springframework.context.annotation.Configuration;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@Configuration
public class CustomFilter implements Filter {

    private static final String[] FREE_URLS = {"/footballer/footballerRegister", "/footballer/login"};

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        String url = request.getRequestURI();
        boolean loginStatus = isFreeURL(url);

        if (!loginStatus || isUserLoggedIn(request)) {
            filterChain.doFilter(request, response);
        } else {
            sendUnauthorizedResponse(response);
        }
    }

    @Override
    public void destroy() {

    }

    private boolean isFreeURL(String url) {
        for (String item : FREE_URLS) {
            if (url.equals(item)) {
                return true;
            }
        }
        return false;
    }

    private boolean isUserLoggedIn(HttpServletRequest request) {
        return request.getSession().getAttribute("footballer") != null;
    }

    private void sendUnauthorizedResponse(HttpServletResponse response) throws IOException {
        PrintWriter printWriter = response.getWriter();
        printWriter.println("{\n" +
                "  \"status\": false,\n" +
                "  \"result\": \"Please Login\"\n" +
                "}");
        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    }
}
