package com.works.entities;

import lombok.Data;

@Data
public class BackUpp {
    private String name;
    private String surname;
    private String teamName;


}


