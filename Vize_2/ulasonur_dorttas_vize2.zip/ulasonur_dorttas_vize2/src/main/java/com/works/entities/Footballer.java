package com.works.entities;

import jakarta.persistence.*;
import javax.validation.constraints.*;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

@Entity
@Data
public class Footballer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer fid;
    @NotEmpty
    private  String ad;
    @NotEmpty
    private String soyad;
    @Email
    @NotEmpty
    @NotNull
    private String email;
    @Length(min = 3, max = 30)
    @NotEmpty
    private String password;
    @Min(18)
    @Column(nullable = false)
    private int age;

    @OneToOne
    private Teams teams;
}
