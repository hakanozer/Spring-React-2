package com.works.entities;

import lombok.Data;

@Data
public class Teamsp {
    private String name;
    private String surname;
    private String tname;

    // Diğer gerekli metotlar ve işlemler
}
