package com.works.repositories;

import com.works.entities.BackUpp;
import com.works.entities.Backup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BackupRepository extends JpaRepository<Backup, Long> {
    @Query(value = "SELECT f.NAME, f.AGE, t.TEAMS\n" +
            "FROM FOOTBOLLERS AS f\n" +
            "INNER JOIN TEAMS t ON f.FID = t.FID\n" +
            "WHERE t.TEAMS IN ('a', 'b')\n" +
            "ORDER BY f.AGE ASC", nativeQuery = true)
    List<BackUpp> list();

}