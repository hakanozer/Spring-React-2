package com.works.repositories;

import com.works.entities.Footballer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FootballerRepository extends JpaRepository<Footballer, Integer> {

}