package com.works.restcontroller;

import com.works.config.Rest;
import com.works.services.BackupService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/backup")
public class BackupController {

    private final BackupService backupService;

    @GetMapping("/backUpCreate")
    public ResponseEntity<Rest> createBackup() {
        String backupData = backupService.backup();
        Rest rest;
        HttpStatus httpStatus;

        if (backupData != null) {
            rest = new Rest(true, backupData);
            httpStatus = HttpStatus.OK;
        } else {
            rest = new Rest(false, "There is no backup available!");
            httpStatus = HttpStatus.BAD_REQUEST;
        }

        return new ResponseEntity<>(rest, httpStatus);
    }
}
