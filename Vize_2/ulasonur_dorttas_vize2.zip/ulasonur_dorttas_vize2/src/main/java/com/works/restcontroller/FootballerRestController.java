package com.works.restcontroller;

import com.works.entities.Footballer;
import com.works.services.FootballerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequiredArgsConstructor
@RequestMapping("/footballer")
public class FootballerRestController {
    final FootballerService footballerService;

    @PostMapping("/save")
    public ResponseEntity save(@Valid @RequestBody Footballer footballer) {
        String s1 = "a10";
        int ca1 = Integer.parseInt(s1);
        return footballerService.save(footballer);
    }

    @GetMapping("/list")
    public ResponseEntity list() {
        return footballerService.list();
    }

}