package com.works.services;

import com.works.entities.BackUpp;
import com.works.repositories.BackupRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BackupService {

    private final BackupRepository backupRepository;

    public String backup() {
        List<BackUpp> backups = backupRepository.list();

        Map<String, List<BackUpp>> backupMap = new HashMap<>();
        backupMap.put("A", filterByTeamName(backups, "A"));
        backupMap.put("B", filterByTeamName(backups, "B"));

        return String.valueOf(backupMap);
    }

    private List<BackUpp> filterByTeamName(List<BackUpp> backups, String teamName) {
        return backups.stream()
                .filter(backUp -> backUp.getName().equals(teamName))
                .collect(Collectors.toList());
    }
}
