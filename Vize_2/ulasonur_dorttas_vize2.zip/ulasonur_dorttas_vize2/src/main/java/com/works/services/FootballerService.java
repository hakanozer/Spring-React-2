package com.works.services;

import com.works.config.Rest;
import com.works.entities.Footballer;
import com.works.repositories.FootballerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class FootballerService {
    final FootballerRepository repository;

    public ResponseEntity save(Footballer footballer) {
        try {
            repository.save(footballer);
            Rest rest = new Rest(true, footballer);
            return new ResponseEntity(rest, HttpStatus.OK);
        } catch (Exception ex) {
            Rest rest = new Rest(false, ex.getMessage());
            return new ResponseEntity(rest, HttpStatus.BAD_REQUEST);
        }
    }

    public ResponseEntity list() {
        Rest rest = new Rest(true, repository.findAll());
        return new ResponseEntity(rest, HttpStatus.OK);
    }

}
