package Ouestion7;

public interface IPalindrome {
    public boolean Palindrome(int number);
}
