package Ouestion7;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Kontrol edilecek sayıyı giriniz:");
        int number = scanner.nextInt();
        İsPalindrome i̇sPalindrome = new İsPalindrome();
        boolean result = i̇sPalindrome.Palindrome(number);
        if (result) {
            System.out.println(number + " sayısı palindromdur");
        } else {
            System.out.println(number + " sayısı polindrom değildir");
        }
    }
}
