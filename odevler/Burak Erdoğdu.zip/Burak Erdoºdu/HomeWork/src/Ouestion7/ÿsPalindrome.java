package Ouestion7;

public class İsPalindrome implements IPalindrome {
    @Override
    public boolean Palindrome(int number) {
        String newnumber = "";
        int controlnumber = number;
        while (controlnumber != 0) {
            int result = controlnumber % 10;
            newnumber = newnumber + Integer.toString(result);
            controlnumber = controlnumber / 10;
        }
        if (number == Integer.valueOf(newnumber)) {
            return true;
        }else {
            return false;
        }

    }
}
