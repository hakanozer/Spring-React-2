package Quesion8;

public class ArrayControl implements IArrayControl {

    @Override
    public int ArrCont(int[] numbers) {
        int maxnumber = 0, minnumber = 0;
        for (int i = 0; i < numbers.length; i++) {
            for (int j = 0; j < numbers.length; j++) {
                if (numbers[i] > numbers[j]) {
                    maxnumber = numbers[i];
                } else if (numbers[i] < numbers[j]) {
                    minnumber = numbers[i];
                }
            }
        }
        return maxnumber + minnumber;
    }
}
