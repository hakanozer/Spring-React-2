package Quesion8;

public interface IArrayControl {
    public int ArrCont(int[] numbers);
}
