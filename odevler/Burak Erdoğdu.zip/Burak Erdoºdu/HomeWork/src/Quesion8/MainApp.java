package Quesion8;

import java.util.ArrayList;

public class MainApp {
    public static void main(String[] args) {
        int[] numbers = {15, 36, 48, 98, 25, 5, 333};
        ArrayControl arrayControl = new ArrayControl();
        int result = arrayControl.ArrCont(numbers);
        System.out.println("dizideki en büyük ve en küçük sayıların toplamı : " + result);
    }
}
