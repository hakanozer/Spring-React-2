package Question1;

import java.util.Scanner;

public class Question1 {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        System.out.println("Kontrolü sağlanacak sayıyı giriniz :");
        int number = read.nextInt();
        Control control = new Control();
        boolean end = control.isPrime(number);
        if (end == true) {
            System.out.println(number + " sayısı asaldır");
        } else {
            System.out.println(number + " sayısı asal değildir");
        }
    }
}
