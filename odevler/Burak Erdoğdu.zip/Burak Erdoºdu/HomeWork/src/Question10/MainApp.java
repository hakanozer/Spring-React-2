package Question10;


import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. Sayıyı giriniz:");
        int number1 = scanner.nextInt();
        System.out.println("2. Sayıyı giriniz:");
        int number2 = scanner.nextInt();
        System.out.println("3. Sayıyı giriniz:");
        int number3 = scanner.nextInt();
        System.out.println("4. Sayıyı giriniz:");
        int number4 = scanner.nextInt();
        NumberControl numberControl = new NumberControl();
        int maxNumber = numberControl.maxNumber(number1,number2,number3,number4);
        System.out.println("En büyük sayı : "+maxNumber);

    }

}
