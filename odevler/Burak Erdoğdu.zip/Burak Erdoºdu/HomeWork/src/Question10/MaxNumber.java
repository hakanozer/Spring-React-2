package Question10;

public abstract class MaxNumber {
    public int maxNumber(int number1, int number2, int number3, int number4) {
        return 0;
    }
}
