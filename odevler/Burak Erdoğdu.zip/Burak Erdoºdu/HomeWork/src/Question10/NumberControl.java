package Question10;

public class NumberControl extends MaxNumber {
    @Override
    public int maxNumber(int number1, int number2, int number3, int number4) {
        if (number1 > number2 && number1 > number3 && number1 > number4) {
            return number1;
        } else if (number2 > number1 && number2 > number3 && number2 > number4) {
            return number2;
        } else if (number3 > number1 && number3 > number2 && number3 > number4) {
            return number3;
        } else {
            return number4;
        }
    }
}
