package Question11;

public interface ITwoArrayContol {
    public int arrControl(int[]numbers,int[] numbers2);
}
