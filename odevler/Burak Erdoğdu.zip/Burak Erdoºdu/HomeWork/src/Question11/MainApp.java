package Question11;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        int[] numbers = new int[5];
        int[] numbers2 = new int[5];
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("1. dizi için " + ++i + ". sayıyı giriniz");
            i--;
            numbers[i] = scanner.nextInt();
        }
        for (int i = 0; i < numbers2.length; i++) {
            System.out.println("2. dizi için " + ++i + ". sayıyı giriniz");
            i--;
            numbers2[i] = scanner.nextInt();
        }
        TwoArrayControl twoArrayControl = new TwoArrayControl();
        int result = twoArrayControl.arrControl(numbers, numbers2);
        System.out.println("iki dizide toplam " + result + " adet sayı ortaktır");
    }
}
