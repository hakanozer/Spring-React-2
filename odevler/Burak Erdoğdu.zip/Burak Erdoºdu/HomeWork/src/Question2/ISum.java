package Question2;

public interface ISum {
    public int collection(int number1,int number2);
}
