package Question2;

import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {

        Scanner read = new Scanner(System.in);
        System.out.println("İlk sayıyı giriniz :");
        int number1 = read.nextInt();
        System.out.println("İkinci sayıyı giriniz :");
        int number2 = read.nextInt();

        Sum sum = new Sum();

        int result = sum.collection(number1,number2);
        System.out.println(number1+" ve "+number2+" arasında ki sayıların toplamı : "+result);
    }
}
