package Question2;

public class Sum implements ISum {
    int end = 0;

    @Override
    public int collection(int number1, int number2) {
        if (number1 < number2) {
            for (int i = number1 +1; i <= number2; i++) {
                end = end + i;
            }

        } else if (number1 >= number2) {
            System.out.println("ilk girilen sayı ikinci sayıdan büyük veya eşit olamaz");
        }
        return end;
    }
}
