package Question3;

public class Control implements IControl {
    @Override
    public double process(double a, double b) {
        double result;
        if (a % 2 == 0) {
            result = a % b;
        } else {
            result = a / b;
        }
        return result;
    }
}
