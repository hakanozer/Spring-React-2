package Question3;

public interface IControl {
    public double process(double a,double b);
}
