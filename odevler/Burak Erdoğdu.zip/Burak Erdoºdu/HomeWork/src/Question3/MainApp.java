package Question3;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.println("Birinci sayıyı giriniz:");
        double num1 = reader.nextDouble();
        System.out.println("İkinci sayıyı giriniz:");
        double num2 = reader.nextDouble();
        Control control = new Control();
        double result = control.process(num1, num2);
        System.out.println("Sonuç : " + result);
    }
}
