package Question4;

public interface ISum {
    public long Process (long num1);
}
