package Question4;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Rakamları toplanacak sayıyı giriniz : ");
        long num1 = scanner.nextLong();
        Sum sum = new Sum();
        long result = sum.Process(num1);
        System.out.println(num1 + " sayısının rakamları toplamı : " + result);
    }
}
