package Question4;

public class Sum implements ISum {

    @Override
    public long Process(long num1) {
        long result = 0;
        while (num1 != 0) {
            result = result + num1 % 10;
            num1 = num1 / 10;
        }
        return result;
    }
}
