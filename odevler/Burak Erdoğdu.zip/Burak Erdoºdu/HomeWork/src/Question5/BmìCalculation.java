package Question5;

public class BmıCalculation implements IBmı{
    @Override
    public double BMI(double kg, double boy) {
        double result;
       return result = kg/(boy*boy);
    }
}
