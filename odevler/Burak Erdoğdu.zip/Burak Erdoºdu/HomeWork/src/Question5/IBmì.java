package Question5;

public interface IBmı {
    public double BMI(double kg,double boy);
}
