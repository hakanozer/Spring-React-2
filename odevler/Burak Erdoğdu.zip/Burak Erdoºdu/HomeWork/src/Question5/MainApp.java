package Question5;

import java.util.*;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Metre cinsinden boyunuzu giriniz:");
        double boy = scanner.nextDouble();
        System.out.println("Kilo bilginizi giriniz:");
        double kg = scanner.nextDouble();
        BmıCalculation bmıCalculation = new BmıCalculation();
        double result = bmıCalculation.BMI(kg, boy);
        System.out.println("BMI(Vücut Kitle İndeksi) sonucunuz : " + result);
    }
}
