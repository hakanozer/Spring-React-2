package Question6;

public interface IReverse {
    public int NumReverse (int num1);
}
