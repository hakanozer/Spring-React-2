package Question6;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Tersi yazılacak sayıyı giriniz : ");
        int num = scanner.nextInt();
        Reverse reverse = new Reverse();
        int reversenumber = reverse.NumReverse(num);
        System.out.println(num + " sayısının tersten yazılmış hali : " + reversenumber);
    }
}
