package Question6;

public class Reverse implements IReverse{
    @Override
    public int NumReverse(int num1) {
        String newnumber = "";
        while (num1 != 0) {
            int result = num1 % 10;
            newnumber = newnumber + Integer.toString(result);
            num1 = num1 / 10;
        }
        return Integer.valueOf(newnumber);
    }
}
