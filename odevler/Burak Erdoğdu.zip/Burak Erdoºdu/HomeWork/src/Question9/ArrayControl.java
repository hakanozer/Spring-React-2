package Question9;

public class ArrayControl extends ControlArr{
    @Override
    public boolean NumberControl(int[] numbers, int number) {
        for (int item : numbers) {
            if (item == number){
                return true;
            }
            break;
        }

        return false;
    }
}
