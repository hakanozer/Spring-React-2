package Question9;

public abstract class ControlArr {
    public boolean NumberControl(int numbers[],int number) {
        return false;
    }
}
