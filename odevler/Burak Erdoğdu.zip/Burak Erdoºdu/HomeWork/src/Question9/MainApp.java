package Question9;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {

        int[] numbers = {15, 16, 85, 93, 456, 86, 1, 75, 89, 325, 157};
        Scanner scanner = new Scanner(System.in);
        System.out.println("Dizinin içinde var mı kotnrol edilecek sayıyı giriniz:");
        int number = scanner.nextInt();
        ArrayControl arrayControl = new ArrayControl();
        boolean result = arrayControl.NumberControl(numbers, number);
        if (result) {
            System.out.println("dizinin içinde " + number + " sayısı bulunuyor");
        } else {
            System.out.println("dizinin içinde " + number + " sayısı bulunmuyor");
        }


    }
}
