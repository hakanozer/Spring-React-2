package com.works.product.controllers;

import com.works.product.services.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProductController {
    Products products = new Products();

    public ProductController() {
    }

    @GetMapping({"/product"})
    public String product() {
        return "product";
    }

    @PostMapping({"/addProduct"})
    public String addProduct(Products products) {
        ProductService service = new ProductService();
        int status = service.addProduct(Products);
        return status > 0 ? "home" : "product";
    }
}