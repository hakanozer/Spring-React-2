package com.works.product.controllers;


public class Products {
    private int pid;
    private String title;
    private int price;
    private String detail;
    private int stock;

    public Products() {
    }

    public int getPid() {
        return this.pid;
    }

    public String getTitle() {
        return this.title;
    }

    public int getPrice() {
        return this.price;
    }

    public String getDetail() {
        return this.detail;
    }

    public int getStock() {
        return this.stock;
    }

    public void setPid(final int pid) {
        this.pid = pid;
    }

    public void setTitle(final String title) {
        this.title = title;
    }

    public void setPrice(final int price) {
        this.price = price;
    }

    public void setDetail(final String detail) {
        this.detail = detail;
    }

    public void setStock(final int stock) {
        this.stock = stock;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof Products)) {
            return false;
        } else {
            Products other = (Products)o;
            if (!other.canEqual(this)) {
                return false;
            } else if (this.getPid() != other.getPid()) {
                return false;
            } else if (this.getPrice() != other.getPrice()) {
                return false;
            } else if (this.getStock() != other.getStock()) {
                return false;
            } else {
                Object this$title = this.getTitle();
                Object other$title = other.getTitle();
                if (this$title == null) {
                    if (other$title != null) {
                        return false;
                    }
                } else if (!this$title.equals(other$title)) {
                    return false;
                }

                Object this$detail = this.getDetail();
                Object other$detail = other.getDetail();
                if (this$detail == null) {
                    if (other$detail != null) {
                        return false;
                    }
                } else if (!this$detail.equals(other$detail)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof Products;
    }

    public int hashCode() {
        int PRIME = true;
        int result = 1;
        result = result * 59 + this.getPid();
        result = result * 59 + this.getPrice();
        result = result * 59 + this.getStock();
        Object $title = this.getTitle();
        result = result * 59 + ($title == null ? 43 : $title.hashCode());
        Object $detail = this.getDetail();
        result = result * 59 + ($detail == null ? 43 : $detail.hashCode());
        return result;
    }

    public String toString() {
        return "Products(pid=" + this.getPid() + ", title=" + this.getTitle() + ", price=" + this.getPrice() + ", detail=" + this.getDetail() + ", stock=" + this.getStock() + ")";
    }
}