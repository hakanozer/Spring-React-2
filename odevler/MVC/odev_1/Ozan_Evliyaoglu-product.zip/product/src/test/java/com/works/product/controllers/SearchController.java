package com.works.product.controllers;

import com.works.product.controllers.Products;
import com.works.product.services.SearchServices;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class SearchController {
    SearchServices services = new SearchServices();

    public SearchController() {
    }

    @GetMapping({"/search"})
    public String search(@RequestParam(defaultValue = "") String q, Model model) {
        List<Products> ls = this.services.search(q);
        model.addAttribute("products", ls);
        model.addAttribute("q", q);
        return "search";
    }
}

