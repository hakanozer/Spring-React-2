package com.works.product.services;
import java.sql.Connection;
import java.sql.DriverManager;

public class DB {
    private final String driver = "com.mysql.cj.jdbc.Driver";
    private final String url = "jdbc:mysql://localhost:3306/java_se";
    private final String username = "root";
    private final String password = "";
    private Connection conn = null;

    public DB() {
    }

    public Connection connect() {
        try {
            if (this.conn == null || this.conn.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                this.conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_se", "root", "");
                System.out.println("Connection Success");
            }
        } catch (Exception var2) {
            System.err.println("Connection Error: " + var2);
        }

        return this.conn;
    }

    public void close() {
        try {
            if (this.conn != null && !this.conn.isClosed()) {
                this.conn.close();
                System.out.println("Connection Close");
            }
        } catch (Exception var2) {
            System.err.println("Close Error : " + var2);
        }

    }
}
