package com.works.product.services;

import com.works.product.controllers.Products;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    public ProductService() {
    }

    public List<Products> products() {
        List<Products> ls = new ArrayList();
        DB db = new DB();

        try {
            String sql = "select * from products";
            PreparedStatement pre = db.connect().prepareStatement(sql);
            ResultSet rs = pre.executeQuery();

            while(rs.next()) {
                Products products = new Products();
                products.setPid(rs.getInt("pid"));
                products.setTitle(rs.getString("title"));
                products.setPrice(rs.getInt("price"));
                products.setDetail(rs.getString("detail"));
                products.setStock(rs.getInt("stock"));
                ls.add(products);
            }
        } catch (Exception var10) {
            System.err.println("Users Err or : " + var10);
        } finally {
            db.close();
        }

        return ls;
    }

    public int addProduct(Products products) {
        DB db = new DB();
        int status = 0;

        try {
            String sql = "insert into products values( null,?,?,?,? )";
            PreparedStatement pre = db.connect().prepareStatement(sql);
            pre.setString(1, products.getTitle());
            pre.setInt(2, products.getPrice());
            pre.setString(3, products.getDetail());
            pre.setInt(4, products.getStock());
            status = pre.executeUpdate();
        } catch (Exception var9) {
            System.err.println("Product Save Exception : " + var9);
        } finally {
            db.close();
        }

        return status;
    }
}