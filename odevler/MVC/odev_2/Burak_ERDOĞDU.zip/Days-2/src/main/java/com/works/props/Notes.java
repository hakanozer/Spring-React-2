package com.works.props;

import lombok.Data;

@Data
public class Notes {
    private int nid;
    private  String title;
    private String detail;
}
