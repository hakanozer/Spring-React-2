package com.works.days2.props;

import lombok.Data;

@Data
public class Notes {
    private int nid;
    private String note;
    private String noteTitle;

}
