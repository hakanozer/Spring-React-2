package com.example.ProductManagementApplication.props;

import lombok.Data;

@Data
public class Products {

    private int pid;
    private String title;
    private int price;
    private String details;
    private int stock;


}
