package com.works.props;

import lombok.Data;

@Data
public class Products {

    private int pid;
    private String title;
    private int price;
    private String detail;
    private int stock;
}
