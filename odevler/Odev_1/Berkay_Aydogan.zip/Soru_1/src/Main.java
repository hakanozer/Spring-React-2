import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("1.Kenar ölçüsünü giriniz: ");
        int kenar1 = scanner.nextInt();
        System.out.print("2.Kenar ölçüsünü giriniz: ");
        int kenar2 = scanner.nextInt();
        System.out.print("3.Kenar ölçüsünü giriniz: ");
        int kenar3 = scanner.nextInt();

        if ((kenar1 + kenar2) >= kenar3) {
            if ((kenar1 + kenar3) >= kenar2) {
                if ((kenar2 + kenar3) >= kenar1) {
                    System.out.println("Ücgen yapabilirsiniz.");
                }
            }
        }
        else{
            System.out.println("Girilen ölcüler ile ücgen yapamazsınız!");
        }

    }
}