public class DegreeToFahrenheit {

    public double convertToFahrenheit(double degree) {
        return (degree * 1.8) + 32;
    }
}
