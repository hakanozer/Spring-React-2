public class FahrenheitToDegree {
    public double convertToDegree(double fahrenheit) {
        return (fahrenheit - 32) * 5/9;
    }
}
