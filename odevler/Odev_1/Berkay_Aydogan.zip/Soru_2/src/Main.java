import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DegreeToFahrenheit degreeToFahrenheit = new DegreeToFahrenheit();
        FahrenheitToDegree fahrenheitToDegree = new FahrenheitToDegree();
        System.out.println("Menu :\n1- F-C\n2- C-F");
        byte secim = scanner.nextByte();

        if (secim == 1) {
            System.out.print("Fahrenheit degerini giriniz: ");
            double fahrenheit = scanner.nextDouble();
            double resultCelcius = fahrenheitToDegree.convertToDegree(fahrenheit);
            System.out.println(fahrenheit + " F = " + resultCelcius + " C");
        } else if (secim == 2) {
            System.out.print("Celcius degerini giriniz: ");
            double celcius = scanner.nextDouble();
            double resultFahrenheit = degreeToFahrenheit.convertToFahrenheit(celcius);

            System.out.println(celcius + " C = " + resultFahrenheit + " C");
        } else {
            System.out.println("Hatalı secim yaptınız!");
        }
        scanner.close();
    }
}