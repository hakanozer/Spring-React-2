import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("1.Sayıyı giriniz: ");
        int sayi1 = scanner.nextInt();
        System.out.print("2.Sayıyı giriniz: ");
        int sayi2 = scanner.nextInt();

        if (sayi1 < sayi2) {
            System.out.println("Büyük sayi: " + sayi2 + " Kücük sayi: " + sayi1);
        } else if (sayi2 < sayi1) {
            System.out.println("Büyük sayi: " + sayi1 + " Kücük sayi: " + sayi2);
        } else {
            System.out.println("Sayılar birbirine eşittir.");
        }
    }
}