import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("3 basamaklı bir sayı giriniz: ");
        int sayi = scanner.nextInt();
        int sum = 0;
        if (100 <= sayi && sayi <= 999) {
            while (sayi > 0) {
                sum = sum + sayi % 10;
                sayi = sayi / 10;
            }
            System.out.println("Sonuc: " + sum);
        } else {
            System.out.println("Girdiginiz sayi 3 haneli degildir.");
        }


    }
}