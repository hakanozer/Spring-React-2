import java.util.Arrays;
import java.util.OptionalDouble;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int pozitifCount = 0;
        int negatifCount = 0;
        int ciftCount = 0;
        int tekCount = 0;
        int toplam = 0;
        int maxSayi = 0;
        int minSayi = 0;
        double ortalama;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Kaç adet sayı girmek istersiniz?  ");
        int toplamSayi = scanner.nextInt();
        int[] arrayN = new int[toplamSayi];
        System.out.println(toplamSayi + " adet sayı giriniz:");

        for (int i = 0; i < toplamSayi; i++) {
            arrayN[i] = scanner.nextInt();
        }

        for (int sayi : arrayN) {
            if (sayi > 0) {
                pozitifCount++;
            } else if (sayi < 0) {
                negatifCount++;
            }
            if (sayi % 2 == 0) {
                ciftCount++;
            } else if (sayi % 2 != 0) {
                tekCount++;
            }
        }
        maxSayi = Arrays.stream(arrayN).max().getAsInt();
        minSayi = Arrays.stream(arrayN).min().getAsInt();
        toplam = Arrays.stream(arrayN).sum();
        ortalama = Arrays.stream(arrayN).average().getAsDouble();

        System.out.println(pozitifCount + " Tanesi Pozitif");
        System.out.println(negatifCount + " Tanesi Negatif");
        System.out.println("En büyügü: " + maxSayi);
        System.out.println("En kücügü: " + minSayi);
        System.out.println(ciftCount + " tanesi çift");
        System.out.println(tekCount + " tanesi tek");
        System.out.println("Toplamlari: " + toplam);
        System.out.println("Ortalamaları: " + ortalama);


    }

}