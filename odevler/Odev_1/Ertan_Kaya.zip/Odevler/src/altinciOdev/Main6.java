package altinciOdev;

import java.util.Scanner;

public class Main6 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String sayi = scanner.nextLine();

        Character.getNumericValue(sayi.charAt(0));
    }
}
