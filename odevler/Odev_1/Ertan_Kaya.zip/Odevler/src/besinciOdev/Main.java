package besinciOdev;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Sayı Giriniz: ");
        String number = scanner.nextLine();
        System.out.println("Girdiğiniz sayı: "+ number);
        int total=0;



        total = Character.getNumericValue(number.charAt(0)) +
                Character.getNumericValue(number.charAt(1)) +
                Character.getNumericValue(number.charAt(2));
        System.out.println(total);

    }
}
