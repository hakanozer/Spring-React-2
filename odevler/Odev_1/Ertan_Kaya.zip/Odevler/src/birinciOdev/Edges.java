package birinciOdev;

public class Edges {

    public void edges (){
        int[] edges =new int[3];
    }
}
