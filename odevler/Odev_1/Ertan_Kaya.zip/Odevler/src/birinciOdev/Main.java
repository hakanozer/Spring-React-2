package birinciOdev;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the first side length: ");
        int side1 = sc.nextInt();

        System.out.print("Enter the second side length: ");
        int side2 = sc.nextInt();

        System.out.print("Enter the third side length: ");
        int side3 = sc.nextInt();

        if (side1 + side2 >= side3 && side2 + side3 >= side1 && side1 + side3 >= side2) {
            System.out.println("It can be a triangle.");
        } else {
            System.out.println("It cannot be a triangle.");
        }
    }
}