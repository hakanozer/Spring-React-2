package dorduncuOdev;

import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bir sayı giriniz: ");
        int number = scanner.nextInt();

        System.out.println("Girdiğiniz sayıya kadar olan toplam = " +(number*(number+1))/2);
    }
}
