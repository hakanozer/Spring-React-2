package ikinciOdev;

import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Menu: ");
        System.out.println("1 F->C");
        System.out.println("2 C->F");
        System.out.println("Choose: ");
        int choose = scanner.nextInt();

        if (choose == 1) {
            System.out.println("You choosed Fahrenheit to Celcius!");
            System.out.print("Enter your Fahrenheit Value:");
            int fahrenheit = scanner.nextInt();
            System.out.println("Fahrenheit's Celcius Value: " + ((fahrenheit-32)*0.5556));
        } else if (choose == 2) {
            System.out.println("You choosed Celcius to Fahrenheit! ");
            System.out.print("Enter your Celcius Value: ");
            int celcius = scanner.nextInt();
            System.out.println("Celcius's Fahrenheit value is: "+ ((celcius*1.8)+32));
        }

    }
}
