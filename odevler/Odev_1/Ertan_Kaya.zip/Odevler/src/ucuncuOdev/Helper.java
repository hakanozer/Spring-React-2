package ucuncuOdev;

public class Helper {
    public void helper() {

    }
}
