package ucuncuOdev;

import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. Sayıyı Giriniz: ");
        int sayi1 = scanner.nextInt();
        System.out.println("1. Girdiğiniz Sayı : "+ sayi1);
        System.out.println("-------------------------");
        System.out.println("2. Sayıyı Giriniz: ");

        int sayi2 = scanner.nextInt();
        System.out.println("2. Girdiğiniz Sayı : "+ sayi2);

        if (sayi2 > sayi1) {
            System.out.println("Küçük Olan Sayı = " + sayi1);
            System.out.println("Büyük olan sayı = "+ sayi2);
        } else if (sayi2==sayi1) {
            System.out.println("Sayılar eşittir.");
        } else {
            System.out.println("Küçük Olan Sayı = " + sayi2);
            System.out.println("Büyük olan sayı = "+ sayi1);
        }
    }
}
