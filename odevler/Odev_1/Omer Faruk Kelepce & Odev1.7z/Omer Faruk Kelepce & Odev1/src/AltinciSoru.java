import java.util.Scanner;

public class AltinciSoru {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.print("Lütfen 3 haneli bir sayı değeri giriniz:");
        int  sayi = input.nextInt();


        if ( (99 < sayi && sayi < 1000)  ) {

            while (sayi > 0) {
                System.out.print ( sayi % 10 );
                sayi /= 10;
            }

        } else {
            System.out.println("Lütfen 3 haneli bir değer girin.");
        }
    }

}
