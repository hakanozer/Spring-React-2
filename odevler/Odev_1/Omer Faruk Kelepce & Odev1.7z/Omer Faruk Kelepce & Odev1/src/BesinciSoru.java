import java.util.Scanner;

public class BesinciSoru {

    public static void main(String[] args) {
        int sayi;
        Scanner input = new Scanner(System.in);
        System.out.print("Lütfen 3 haneli bir sayı değeri giriniz:");
        sayi = input.nextInt();

        if ( (99 < sayi && sayi < 1000) || ( -99 > sayi && sayi > -1000 ) ) {
           int toplam = 0;
           while ( sayi != 0 ){
               toplam += (sayi%10);
               sayi /= 10;
           }
           System.out.println("Basamak toplamı: " + toplam);
        } else {
            System.out.println("Lütfen 3 haneli bir değer girin.");
        }

    }
}
