import java.util.Scanner;

public class BirinciSoru {

    public static void main(String[] args) {
        int kenar1, kenar2, kenar3;
        boolean ucgenOlabilir = false;

        Scanner input = new Scanner(System.in);
        System.out.print("Lütfen üçgenin ilk kenarını giriniz: ");
        kenar1 = input.nextInt();
        System.out.print("Lütfen üçgenin ikinci kenarını giriniz: ");
        kenar2 = input.nextInt();
        System.out.print("Lütfen üçgenin üçüncü kenarını giriniz: ");
        kenar3 = input.nextInt();

        if (kenar1+kenar2 >= kenar3 ) {
            if (kenar1+kenar3 >= kenar2){
                if (kenar2 + kenar3 >= kenar1){
                    System.out.println("Üçgen olabilir.");
                    ucgenOlabilir = true;
                }
            }
        }
        if (!ucgenOlabilir) {
            System.out.println("Herbir kenar diğer 2 kenar toplamından küçük veya eşit olmalı!!!\nÜçgen olamaz");
        }

    }
}

