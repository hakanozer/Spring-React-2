import java.util.Scanner;

public class DorduncuSoru {

    public static void main(String[] args) {
        int tavanSayi;
        int sum = 0;

        Scanner input = new Scanner(System.in);
        System.out.print("Birden itibaren kaça kadar toplanması gerektiğini giriniz: ");
        tavanSayi = input.nextInt();
        int[] sayiArr = new int[tavanSayi];


        if (tavanSayi <= 0) {
            System.out.println("Hatalı giriş yaptınız!");
        }

        for (int i = 0; i <= tavanSayi ; i++){
            sum += i;
        }

        System.out.println("Toplam değer = " + sum);
    }
}
