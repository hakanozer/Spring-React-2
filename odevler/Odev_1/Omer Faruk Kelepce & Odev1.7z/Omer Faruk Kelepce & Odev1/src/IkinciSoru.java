import java.util.Scanner;

public class IkinciSoru {

    public static void main(String[] args) {
        double sonDeger;
        Scanner input = new Scanner(System.in);
        System.out.print("Lütfen girmek istediğiniz sıcaklık türünü seçin;\n " +
                "Celcius'tan Fahreinheit'a çevirmek için 1,\n " +
                "Fahreinheit'tan Celcius'a çevirmek için 2'yi girin: ");

        int sicaklikTuru = input.nextInt();
        System.out.print("Lütfen dereceyi giriniz: ");
        int derece = input.nextInt();

        if (sicaklikTuru == 1) {
            sonDeger = derece * 1.8 + 32;
            System.out.println("Girdiğiniz " + derece + " derece, " + sonDeger + " fahreinheit'tır.");
        } else if (sicaklikTuru == 2){
            sonDeger = (derece - 32) / 1.8;
            System.out.println("Girdiğiniz " + derece + " fehreinheit, " + sonDeger + " derece'dir.");
        } else {
            System.out.println("Hatalı değer girdiniz, lütfen kontrol edin.");
        }

    }
}
