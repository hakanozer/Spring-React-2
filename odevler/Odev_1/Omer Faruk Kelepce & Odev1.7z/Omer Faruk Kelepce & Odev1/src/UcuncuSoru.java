import java.util.Scanner;

public class UcuncuSoru {

    public static void main(String[] args) {
        int num1, num2;
        Scanner input = new Scanner(System.in);
        System.out.print("Lütfen ilk değeri girin: ");
        num1 = input.nextInt();
        System.out.print("Lütfen ikinci değeri girin: ");
        num2 = input.nextInt();

        if (num1 > num2) {
            System.out.println(num1 + " değeri " + num2 + " değerinden büyüktür.");
        } else if (num1 < num2) {
            System.out.println(num1 + " değeri " + num2 + " değerinden küçüktür.");
        } else {
            System.out.println("Girilen iki değer birbirine eşittir.");
        }


    }
}
