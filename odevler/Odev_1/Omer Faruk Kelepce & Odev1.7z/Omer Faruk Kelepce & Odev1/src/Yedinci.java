import java.util.Scanner;

public class Yedinci {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Kaç adet sayı gireceksiniz: ");
        int girilecekSayiAdedi = input.nextInt();
        int[] arr = new int[girilecekSayiAdedi];
        int count = 0;

        while(count != girilecekSayiAdedi){
            System.out.print((count +1) + ". değeri girin: ");
            arr[count] = input.nextInt();
            count++;
        }

        int maks = arr[0];
        int min = arr[0];
        int ciftSayiAdedi= 0;
        int tekSayiAdedi = 0;
        int pozitifSayiAdedi = 0;
        int negatifSayiAdedi = 0;
        int sum = 0;
        double avarage = 0;

        for (int i = 0; i < arr.length; i++){

            sum += arr[i];
            avarage = sum / arr.length;

            if (arr[i] < min){
                min = arr[i];
            }
            if (arr[i] > maks) {
                maks = arr[i];
            }
            if( arr[i] < 0) {
                negatifSayiAdedi++;
            }
            if( arr[i] > 0) {
                pozitifSayiAdedi++;
            }
            if( Math.abs(arr[i]) %2 == 0 ) {
                ciftSayiAdedi++;
            }
            if( Math.abs(arr[i]) %2 == 1) {
                tekSayiAdedi++;
            }
        }
        System.out.println("Girilen " + arr.length + " adet sayıdan: ");
        System.out.println( pozitifSayiAdedi + " tanesi pozitiftir." );
        System.out.println( negatifSayiAdedi + " tanesi negatiftir." );
        System.out.println("Girilen sayılardan en büyüğü " + maks);
        System.out.println("Girilen sayılardan en küçüğü " + min);
        System.out.println("Girilen sayıların " + ciftSayiAdedi + " tanesi çift.");
        System.out.println("Girilen sayıların " + tekSayiAdedi + " tanesi tek.");
        System.out.println("Girilen sayıların toplamı " + sum );
        System.out.println("Girilen sayıların ortalaması " + avarage);
    }
}
