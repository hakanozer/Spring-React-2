package Example;

import java.util.Scanner;

public class MainQuestions {
    public static void main(String[] args) {

        // kullanıcıdan 3 kenar değeri alıyorsun Bu 3 değerden üçgen yapılıp yapılamayacağını test edip sonucu bastıracaksınız
        int n1,n2,n3;
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. kenar değerini giriniz");
        n1=scanner.nextInt();
        Scanner scanner2 = new Scanner(System.in);
        System.out.println("2. kenar değerini giriniz");
        n2=scanner.nextInt();
        Scanner scanner3 = new Scanner(System.in);
        System.out.println("3. kenar değerini giriniz");
        n3=scanner.nextInt();
        if (n1+n2>=n3 || n2+n1>=n3 || n2+n3>=n1)
        {
            System.out.println("Üçgen yapılıyor");
        }
        else System.out.println("Üçgen yapılamıyor");

    }
}
