package Example_2;

import java.util.Scanner;

public class MainQuestions2 {
/*
2 - Kullanıcıya Aşağıdaki Menuyu Gösteriyorsunuz

	Menu :
	1 - F -> C
	2 - C -> F
	    Secim :

	Kullanıcı 1'i Seçerse Fahrenheit Değerini Alıyorsunuz
	Girilen Değeri Dereceye Çevirip
	x F = y C Şeklinde Ekranda Gösteriyorsunuz

	Eğer 2. Seçenek Seçildiyse, C Değerini Alıyorsunuz
	Girilen Değeri Fahrenheit'a Çevirip
	x C = y F Şeklinde Ekranda Gösteriyorsunuz

	Eğer Kullanıcı Menu Seceneginde 1,2 Dışında Bir Sayı
	Girerse Ekrana Hatalı Seçim Mesajını Bastırmalısınız

 */
    public static void main(String[] args) {
        int vote,s1,s2;
        float fah,cel;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Menü \n 1- F->C \n 2- C->F");
        System.out.println("Bir seçim yapınız");
        vote=scanner.nextInt();
        if (vote>0 && vote<3)
        {
        switch (vote)
        {
            case 1:
                Scanner scanner2= new Scanner(System.in);
                System.out.println("Bir Fahrenheit değeri giriniz");
                fah=scanner2.nextFloat();
                cel  = ((fah-32)*5)/9;
                System.out.println("x"+fah+"="+"y"+cel);
                break;
            case 2:
                Scanner scanner3= new Scanner(System.in);
                System.out.println("Bir Celsius değeri giriniz");
                cel=scanner3.nextFloat();
                fah= ((cel*9)/5)+32;
                System.out.println("y "+cel+" = "+"x "+fah);
                break;
        }
    }
        else System.out.println("Hatalı Seçim");
    }
}
