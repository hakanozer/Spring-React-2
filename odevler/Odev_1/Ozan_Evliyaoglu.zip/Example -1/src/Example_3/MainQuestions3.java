package Example_3;

import java.util.Scanner;

public class MainQuestions3 {
    /*
    3 - Kullanıcıdan 2 Sayı Alıyorsunuz
	Bu 2 Büyük ve Küçük Olanını Ekrana Bastırıyorsunuz
	Eğer Sayılar Eşitse Sayılar Eşittir Mesajını
	Ekrana Bastırıyorsunuz
     */
    public static void main(String[] args) {
      int s1,s2;
        Scanner scanner = new Scanner(System.in);
        System.out.println("1.Sayıyı Giriniz");
        s1=scanner.nextInt();
        Scanner scanner2 = new Scanner(System.in);
        System.out.println("2.Sayıyı Giriniz");
        s2=scanner2.nextInt();

        if (s1>s2) {
            System.out.println("Büyük olan sayı :" + s1 + "\n Küçük olan sayı :" + s2);
        }
         else if (s2 > s1) {
                System.out.println("Büyük olan sayı :" + s2 + "\n Küçük olan sayı :" + s1);

            } else
          {
                System.out.println("Sayılar Eşittir: " + s1 + "=" + s2);

            }
    }
}
