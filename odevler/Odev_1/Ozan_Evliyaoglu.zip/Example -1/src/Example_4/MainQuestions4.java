package Example_4;

import java.util.Scanner;

public class MainQuestions4 {
    /*
4 - Kullanıcıdan Bir N Sayısı Alıyorsunuz
1'den N'e Kadar Olan Sayıların Toplamını
Ekrana Bastırıyorsunuz (Formulü Araştırın)
 */
    public static void main(String[] args) {
       int s1,sum=0;
        Scanner scanner= new Scanner(System.in);
        System.out.println("Bir sayı giriniz");
        s1=scanner.nextInt();
        for (int i = 1; i <=s1; i++) {
            System.out.println(i);
            sum+=i;
        }
        System.out.println("1'den "+s1+"sayısına kadar olan sayıların toplamı:"+sum);

    }
}
