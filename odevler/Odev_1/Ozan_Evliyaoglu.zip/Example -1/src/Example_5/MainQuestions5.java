package Example_5;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.util.Scanner;

public class MainQuestions5 {
    /*
    5 - Kullanıcıdan 3 Haneli Bir Sayı
	Alıyorsunuz. Bu Sayının
	Basamaklarının Toplamını
	Yazdırıyorsunuz

	Örnek :
	Sayı Girin : 245
	2 + 4 + 5 = 11
     */
    public static void main(String[] args) {
        int s1,sum=0,b,o,y;
        Scanner scanner= new Scanner(System.in);
        System.out.println("3 Haneli bir sayı giriniz");
        s1=scanner.nextInt();
        if (s1>=100 && s1<=1000)
        {
            y=s1/100;
            s1=s1-(100*y);

            o=s1/10;
            s1=s1-(10*o);

            b=s1;

            System.out.println("Sayının Basamaklarına Ayrılmış Hali: "+y+" "+o+" "+b);
            sum= y+o+b;
            System.out.println("Toplamı:"+sum);
        }
    }
}
