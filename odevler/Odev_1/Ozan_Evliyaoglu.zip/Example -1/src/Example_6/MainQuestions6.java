package Example_6;

import java.util.Scanner;

public class MainQuestions6 {
    /*
    6 - Kullanıcıdan 3 Haneli Bir Sayı
	Alıyorsunuz. Bu Sayının
	Rakamlarını Tersten Yazdırıyorsunuz
	Örnek :
	Sayı Girin : 743
	347
     */
    public static void main(String[] args) {
        int s1,reverse=0;
        Scanner scanner= new Scanner(System.in);
        System.out.println("3 Haneli bir sayı giriniz");
        s1=scanner.nextInt();
        if (s1>=100 && s1<=1000)
        {
          reverse= reverse*10;
            reverse= reverse+s1%10;
            s1=s1/10;
            System.out.println("Ters Çevrilen Hali:"+reverse);
        }


    }
}
