package soru4;

public class ActionToplam {
    public int toplam(int gelensayi){
        int gidensayi;

        gidensayi=(gelensayi*(gelensayi+1))/2;

        return gidensayi;
    }
}
