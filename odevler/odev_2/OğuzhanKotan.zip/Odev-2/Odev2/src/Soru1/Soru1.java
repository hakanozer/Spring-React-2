package Soru1;

import java.sql.SQLOutput;

public class Soru1 {

    public Soru1(int sayi){
        isPrime(sayi);
    }
    public static boolean isPrime(int n){
        int sayac = 0;
        if(n==2){
            return true;
        }
        for(int i=2; i<n; i++){
            if(n % i == 0){
                sayac++;
            }
        }
        if(sayac == 0){
            return true;
        }else {
            return false;
        }
    }

    public static void main(String[] args) {
        System.out.println(isPrime(19));
    }
}

