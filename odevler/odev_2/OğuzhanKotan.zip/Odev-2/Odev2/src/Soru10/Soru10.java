package Soru10;

public class Soru10 {
    public int biggest(int a,int b,int c, int d){
        int[] arr = {a,b,c,d};
        int n = arr[0];
        for(int i = 0; i < arr.length; i++){
            if(arr[i] > n){
                n = arr[i];
            }
        }
        return n;
    }

    public static void main(String[] args) {
        Soru10 soru10 = new Soru10();
        System.out.println(soru10.biggest(1,2,3,4));
    }
}
