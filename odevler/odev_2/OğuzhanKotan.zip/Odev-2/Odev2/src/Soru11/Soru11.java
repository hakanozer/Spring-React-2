package Soru11;

import java.sql.SQLOutput;
import java.util.Arrays;
import java.util.function.IntPredicate;

public class Soru11 {
    int sayac = 0;
    public int common(int[]arr1,int[]arr2){
        for (int i = 0; i < arr1.length; i++) {
            for (int j = 0; j < arr2.length; j++) {
                if(arr1[i] == arr2[j]){
                    sayac++;
                }
            }
        }
        return sayac;
    }

    public static void main(String[] args) {
        int[] array1 = {1,2,3,4};
        int[] array2 = {3,4,5,6};
        Soru11 soru11 = new Soru11();
        System.out.println(soru11.common(array1,array2));
    }
}
