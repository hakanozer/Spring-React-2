package Soru2;

public interface ISoru2 {
    public int topla(int sayi1,int sayi2);
}
