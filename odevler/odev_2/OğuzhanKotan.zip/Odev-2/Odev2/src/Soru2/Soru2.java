package Soru2;

public class Soru2 implements ISoru2{

    int sonuc = 0;
    @Override
    public int topla(int sayi1, int sayi2) {
        for(int i = sayi1; i <= sayi2; i++){
            sonuc += i;
        }
        return sonuc - sayi1;
    }

    public static void main(String[] args) {
        Soru2 soru2 = new Soru2();
        System.out.println(soru2.topla(5,10));
    }
}

