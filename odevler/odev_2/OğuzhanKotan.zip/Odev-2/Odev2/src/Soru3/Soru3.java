package Soru3;

public class Soru3 {

    public Soru3(int sayi1,int sayi2){
        System.out.println(method(sayi1, sayi2));
    }
    public double method(int a,int b){
        if(a % 2 == 1){
            return a/b;
        }else if(a % 2 == 0){
            return a % b;
        }
        return 0;
    }

    public static void main(String[] args) {
        Soru3 soru3 = new Soru3(19,4);
    }
}
