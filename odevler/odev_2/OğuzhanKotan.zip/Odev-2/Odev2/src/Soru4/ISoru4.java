package Soru4;

public interface ISoru4 {
    public double method(long sayi);
}
