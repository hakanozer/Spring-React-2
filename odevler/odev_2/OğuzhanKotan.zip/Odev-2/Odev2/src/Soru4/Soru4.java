package Soru4;

public class Soru4 implements ISoru4{

    long rakam,toplam = 0;
    @Override
    public double method(long sayi) {
        while(sayi > 0) {
            rakam = sayi % 10;
            toplam += rakam;
            sayi = sayi / 10;
        }
        return toplam;
    }

    public static void main(String[] args) {
        Soru4 soru4 = new Soru4();
        System.out.println(soru4.method(1231213131));
    }
}
