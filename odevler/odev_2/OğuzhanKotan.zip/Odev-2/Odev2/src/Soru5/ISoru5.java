package Soru5;

public interface ISoru5 {
    public double bmi(int kg,double boy);
}
