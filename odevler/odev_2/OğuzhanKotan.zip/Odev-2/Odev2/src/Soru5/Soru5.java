package Soru5;

public class Soru5 implements ISoru5{
    @Override
    public double bmi(int kg, double boy) {
        return kg / (boy*boy);
    }

    public static void main(String[] args) {
        Soru5 soru5 = new Soru5();
        System.out.println(soru5.bmi(77,1.86));
    }
}
