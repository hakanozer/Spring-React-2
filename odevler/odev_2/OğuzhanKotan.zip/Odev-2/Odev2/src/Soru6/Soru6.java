package Soru6;

import javax.sound.midi.Soundbank;
import java.sql.SQLOutput;

public class Soru6 {
    public int reverse(int n){
       while(n>0){
           System.out.print(n%10);
           n /= 10;
       }
       return 0;
    }

    public static void main(String[] args) {
        Soru6 soru6 = new Soru6();
        soru6.reverse(456);
    }
}
