package Soru7;

public class Soru7 {

    int asilSayi,sayi,reverse=0,remainder;

    public boolean palindrome(int sayi){
        this.sayi = sayi;
        asilSayi = sayi;
        while(sayi != 0){
            remainder = sayi % 10;
            reverse = reverse * 10 + remainder;
            sayi /= 10;
        }
        if( asilSayi == reverse){
            return true;
        }else{
            return false;
        }
    }

    public static void main(String[] args) {
        Soru7 soru7 = new Soru7();
        System.out.println(soru7.palindrome(1441));
    }
}
