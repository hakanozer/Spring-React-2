package Soru8;

public class Soru8 {

    int enBuyuk,enKucuk;
    public int method(int[] arr){
        enBuyuk = arr[0];
        enKucuk = arr[0];
        for(int i = 0; i < arr.length; i++){
            if(arr[i] > enBuyuk){
                enBuyuk = arr[i];
            }
            if(arr[i] < enKucuk){
                enKucuk = arr[i];
            }
        }
        return enKucuk + enBuyuk;
    }

    public static void main(String[] args) {
        int[] arr = {10,20,30,40};
        Soru8 soru8 = new Soru8();
        System.out.println(soru8.method(arr));
    }
}
