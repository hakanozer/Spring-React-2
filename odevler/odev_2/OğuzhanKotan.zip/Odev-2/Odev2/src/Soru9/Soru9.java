package Soru9;

public class Soru9 {

    public boolean isExist(int[] arr,int sayi){
        for(int i = 0; i < arr.length; i++){
            if(arr[i] == sayi){
                return true;
            }else{
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        int[] arr2 = {10,20,30};
        Soru9 soru9 = new Soru9();
        System.out.println(soru9.isExist(arr2,10));
    }
}
