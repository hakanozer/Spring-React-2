package soru1;

public abstract class AsalMiAbstract {

public abstract boolean asal();

}
