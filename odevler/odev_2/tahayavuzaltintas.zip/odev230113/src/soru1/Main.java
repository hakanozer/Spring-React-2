package soru1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int a;
        System.out.println("asal sayılar 2'den başlar");
        Scanner scanner=new Scanner(System.in);
        a=scanner.nextInt();
        isPrime prime=new isPrime(a);
        System.out.println(prime.asal());
    }
}