package soru1;

public class isPrime extends AsalMiAbstract {

    boolean b=true;
    public isPrime(int gelen){
        boolean b;
        for (int i = 2; i <gelen ; i++) {
            int a=gelen%i;
            if (a==0){
                b=false;
                this.b=b;
                break;
            }
            else{


            }

        }


    }



    @Override
    public boolean asal() {
        return this.b;
    }
}
