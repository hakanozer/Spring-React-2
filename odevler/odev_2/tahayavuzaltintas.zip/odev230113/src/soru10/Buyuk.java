package soru10;


    public class Buyuk extends BuyukAbs{


        @Override
        public int Buyuk(int[] dizi) {


                int max=dizi[0];

                for (int deger:dizi) {

                    if(deger>max){
                        max=deger;
                    }


                }


                return max;
        }

    }




