package soru10;

public abstract class BuyukAbs {

    public abstract int Buyuk(int[] dizi);

}
