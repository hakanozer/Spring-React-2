package soru10;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        int [] input = new int [] {scanner.nextInt(), scanner.nextInt(), scanner.nextInt(),scanner.nextInt()};


        Buyuk buyuk=new Buyuk();
        System.out.println(buyuk.Buyuk(input));




    }


}
