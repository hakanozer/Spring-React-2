package soru11;

public class Dondur extends DondurAbs{
    @Override
    public int don(int[] dizi1, int[] dizi2) {

        int say=0;

        for (int i = 0; i < dizi1.length ; i++) {
            for (int j = 0; j < dizi2.length; j++) {

                if(dizi1[i]==dizi2[j]){

                    say++;

                }

            }

        }

        return say;
    }
}
