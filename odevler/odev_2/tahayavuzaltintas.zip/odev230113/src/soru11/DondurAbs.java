package soru11;

public abstract class DondurAbs {

    public abstract int don(int[] dizi1,int[] dizi2);


}
