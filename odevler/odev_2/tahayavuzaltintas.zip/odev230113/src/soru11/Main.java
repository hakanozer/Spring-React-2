package soru11;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);

        System.out.println("1.dizi için kaç sayı gireceksiniz");
        int a=scanner.nextInt();
        int[] dizi1=new int[a];
        for (int i = 0; i < a; i++) {
            dizi1[i]=scanner.nextInt();
        }

        System.out.println("2.dizi için kaç sayı gireceksiniz");
        int b=scanner.nextInt();
        int[] dizi2=new int[b];
        for (int i = 0; i < b; i++) {
            dizi2[i]= scanner.nextInt();
        }

        Dondur dondur=new Dondur();

        System.out.println(dondur.don(dizi1,dizi2));


        
    }
    
}
