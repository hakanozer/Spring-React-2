package soru2;

public interface Deger {



    int degergiris(int a,int b);





}
