package soru2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner scanner=new Scanner(System.in);

        int a= scanner.nextInt();
        int b= scanner.nextInt();



        Deger deger1=new Deger() {
            @Override
            public int degergiris(int a, int b) {
                int toplam=0;
                for (int i = a+1; i <= b ; i++) {
                    toplam=toplam+i;
                }

                return toplam;
            }
        };
        System.out.println(deger1.degergiris(a,b));

    }



}
