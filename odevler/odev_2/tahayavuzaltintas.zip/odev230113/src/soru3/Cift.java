package soru3;

public class Cift extends Tek{

    @Override
    public double Tek(int a, int b) {


        return a%b;
    }
}
