package soru3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        int a=scanner.nextInt();
        int b=scanner.nextInt();



        Tek tek=new Tek();
        Tek cift=new Cift();
        if (a%2==1){
            System.out.println(tek.Tek(a,b));
        }
        else if (a%2==0) {
            System.out.println(cift.Tek(a,b));
        }







    }

}
