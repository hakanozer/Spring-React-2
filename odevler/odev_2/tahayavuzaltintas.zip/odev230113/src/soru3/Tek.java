package soru3;

public class Tek {

    public double Tek(int a,int b){


        return a/b;
    }



}
