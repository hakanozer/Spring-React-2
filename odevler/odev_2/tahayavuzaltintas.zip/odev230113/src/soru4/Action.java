package soru4;

public class Action extends ToplamAbs {

    @Override
    public long toplam(long a) {

        long toplam=0;

        while(a != 0)
        {
            toplam=(a%10)+toplam;
            a = a / 10;
        }

        System.out.println( toplam);


        return toplam;
    }
}
