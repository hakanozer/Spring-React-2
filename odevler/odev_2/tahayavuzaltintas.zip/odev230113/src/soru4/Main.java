package soru4;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        long g=scanner.nextLong();

        Action action=new Action();
        action.toplam(g);




    }

}
