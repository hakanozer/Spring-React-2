package soru4;

public abstract class ToplamAbs {

    public abstract long toplam(long a);

}
