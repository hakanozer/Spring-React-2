package soru5;

public class BoyKg extends BoyKgAbs {

    @Override
    public double dondur(double boy,double kg) {
        double dondur=kg/boy;

        return dondur*dondur;
    }
}
