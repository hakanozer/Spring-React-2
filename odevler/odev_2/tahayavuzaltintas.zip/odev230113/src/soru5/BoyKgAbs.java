package soru5;

public abstract class BoyKgAbs {

    public abstract double dondur(double boy,double kg);

}
