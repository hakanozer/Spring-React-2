package soru5;

import soru4.Action;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        double boy=scanner.nextDouble();
        double kg= scanner.nextDouble();

       BoyKg boyKg=new BoyKg();

        System.out.println(boyKg.dondur(boy,kg));

    }





}
