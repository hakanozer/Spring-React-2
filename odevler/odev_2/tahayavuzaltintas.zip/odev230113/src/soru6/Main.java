package soru6;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        System.out.println("kaç basamaklı sayı gireceksiniz :");
        int b=scanner.nextInt();
        int a=scanner.nextInt();

        Ters ters=new Ters();
        int yaz[]=ters.tersle(a,b);

        for (int i:yaz             ) {

            System.out.print(i);
        }





    }

}
