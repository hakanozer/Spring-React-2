package soru6;

public class Ters extends TersAbs {

    @Override
    public int[] tersle(int a,int b) {

        int dizi[]=new int[b];
        int i=0;

        while (a > 0) {

            dizi[i]=a % 10;
            a /= 10;
            i++;

        }

        return dizi;

    }
}
