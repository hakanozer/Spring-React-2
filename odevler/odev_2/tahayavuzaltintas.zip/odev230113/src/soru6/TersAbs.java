package soru6;

public abstract class TersAbs {

    public abstract int[] tersle(int a,int b);



}
