package soru7;

public abstract class AbsPalindrome {

    public abstract boolean pal(int sayi);

}
