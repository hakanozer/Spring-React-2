package soru7;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        int sayi= scanner.nextInt();

        Palindrome palindrome=new Palindrome();
        System.out.println(palindrome.pal(sayi));


    }

}
