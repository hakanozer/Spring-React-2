package soru7;

public class Palindrome extends AbsPalindrome {

    int kalan=0;
    int ters=0;
    int dsayi;

    @Override
    public boolean pal(int sayi) {

        dsayi=sayi;

        while(dsayi != 0){
            kalan = dsayi% 10;
            ters = ters * 10 + kalan;
            dsayi /= 10;
        }
        if( sayi == ters){
            return true;
        }else{
            return false;
        }


    }
}
