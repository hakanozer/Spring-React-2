package soru8;

public class EnKucuk extends EnBuyuk {

    public int Kucuk(int[] dizi) {
        int min=dizi[0];

        for (int deger:dizi) {

            if(deger<min){
                min=deger;
            }


        }


        return min;
    }

    @Override
    public int Buyuk(int[] dizi) {
        return super.Buyuk(dizi);
    }
}
