package soru8;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        EnKucuk enKucuk=new EnKucuk();

        Scanner scanner=new Scanner(System.in);
        int[] input= new int[]{scanner.nextInt(), scanner.nextInt(), scanner.nextInt()};


        System.out.println((enKucuk.Kucuk(input))+ ((enKucuk.Buyuk(input))));








    }

}
