package soru9;

public class Main {

    public static void main(String[] args) {

        TF tf=new TF();
        int[] a={1,2,3};
        System.out.println(tf.icermek(a,5));





    }


}
