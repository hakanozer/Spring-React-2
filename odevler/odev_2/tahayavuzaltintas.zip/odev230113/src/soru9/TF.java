package soru9;

public class TF extends TFAbs{

    @Override
    public boolean icermek(int[] sayi1, int sayi2) {

            boolean b=false;

            for (int dizi:sayi1){
                if(dizi==sayi2){

                    b=true;
                    break;
                }
                else{
                    b=false;
                }

            }


        return b;
    }
}
