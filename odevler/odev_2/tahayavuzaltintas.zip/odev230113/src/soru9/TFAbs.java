package soru9;

public abstract class TFAbs {

    public abstract boolean icermek(int[] sayi1,int sayi2);





}
